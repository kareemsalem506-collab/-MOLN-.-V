# MOLN V — Haute Parfumerie E-Commerce Platform

A complete, mobile-first e-commerce web platform and store management console designed for **MOLN V**, a luxury fragrance brand targeting connoisseurs across the Gulf region (Saudi Arabia, UAE, Kuwait, Qatar, Bahrain, Oman).

Inspired by the editorial elegance, sensory storytelling, and visual refinement of **Amouage** and **Assaf (3saf)**, the website features an original brand aesthetic utilizing the official MOLN V monogram logo and brand palette:
- **Ice Blue:** `#D6E6F3`
- **Powder Blue:** `#A6C5D7`
- **Sapphire:** `#0F52BA`
- **Deep Navy:** `#000926`

---

## Key Features & Solved Customer Concerns

### 1. Overcoming the "Blind-Buying" Online Fragrance Dilemma
Buying perfume online without smelling it creates purchase hesitation. MOLN V directly addresses this through:
- **Interactive Scent Finder Quiz (`discovery.html`):** A 3-question guided diagnostic assessing character, wearing environment, and projection to recommend the optimal edition.
- **The Discovery Wardrobe Coffret (5 × 10ml):** Allows customers to sample all 5 editions on their own skin at home, complete with an included **100 SAR full-bottle credit voucher**.
- **Transparent Olfactory Pyramid:** Complete, structured breakdown of **Top Notes**, **Heart Notes**, and **Base Notes** on each product profile.

### 2. Tailored Specifically for Gulf Consumers
- **Multi-Currency Engine:** Live dynamic conversion across all 6 GCC currencies (**SAR, AED, KWD, QAR, BHD, OMR**) and **USD**, saved across sessions.
- **Gulf Payment Gateways:** Dedicated visual support and checkout simulations for **Mada**, **Apple Pay**, **Tabby** (4-split interest free), **Tamara** (4-split), Visa, Mastercard, and Cash on Delivery.
- **GCC Address Format:** Optimized for Saudi National Address (Short code, District, City), UAE Emirates, and GCC mobile numbers.
- **Floating WhatsApp Concierge:** Direct one-click chat with pre-filled inquiries, reflecting the communication habits of Gulf luxury shoppers.

### 3. Secured Brand Management Console & RBAC Architecture
Administrative control is separated from the public customer storefront using a server-side authentication model:
- **Server-Side Authentication (`server.py`):** PBKDF2 salted password hashing (100,000 iterations) and cryptographically secure tokens with `HttpOnly; SameSite=Strict` cookies.
- **Role-Based Access Control (RBAC):** Customer accounts attempting to navigate to admin URLs or endpoints are rejected with **HTTP 403 Forbidden**.
- **Static Frontend Lockdown:** In static hosting environments (such as Vercel or GitHub Pages), `admin.html` serves an explicit **HTTP 403 Access Denied** lockdown notice, preventing unauthorized client-side access or data leakage.
- **Admin Capabilities (Authenticated Session Only):**
  - **Dashboard Overview:** Live calculation of Total Revenue, Orders, Average Order Value (AOV), and customer inquiry volume.
  - **Fragrance Catalog Manager:** Add, edit, or delete fragrance editions, prices in SAR, stock counts, badges, and olfactory accords.
  - **Order Fulfillment Manager:** Track customer orders and transition fulfillment statuses (`Processing` → `In Transit` → `Delivered` → `Cancelled`).
  - **Concierge Inquiries Inbox:** View messages submitted via `contact.html` with direct email or WhatsApp reply links.
  - **Store & GCC Settings:** Configure store name, announcement banner, contact numbers, WhatsApp concierge digits, and complimentary shipping thresholds.

---

## Project Structure

```
.
├── index.html                  # Editorial Homepage with discovery quiz & featured editions
├── shop.html                   # Catalog with olfactory family filters & sorting
├── product.html                # Product Detail Page with pyramid accords & sticky mobile bar
├── discovery.html              # Dedicated 3-step Scent Profiler quiz
├── cart.html                   # Dedicated Shopping Bag with quantity controls & free shipping bar
├── checkout.html               # 3-step GCC checkout (Contact, Shipping, Payment)
├── order-confirmation.html     # Live order receipt & dispatch tracking visualizer
├── account.html                # Customer portal: Order history, GCC addresses, Wishlist (zero admin links)
├── about.html                  # Brand narrative & craftsmanship (editable placeholders)
├── contact.html                # Inquiries form & direct WhatsApp concierge
├── faq.html                    # FAQ addressing blind-buying, GCC shipping & policy drafts
├── search.html                 # Live search with accord suggestions
├── 404.html                    # Branded 404 error page
├── shipping-policy.html        # Draft regional shipping policy template
├── refund-policy.html          # Draft returns & seal integrity policy template
├── privacy-policy.html         # Draft GCC PDPL-compliant privacy template
├── terms.html                  # Draft terms of service template
├── admin.html                  # Static 403 Lockdown page (Server serves authenticated dashboard)
├── server.py                   # Secure preview web server with RBAC & session authentication
├── LAUNCH_CHECKLIST.md         # Deployment guide & platform recommendation analysis
└── assets/
    ├── css/
    │   ├── style.css           # Brand design system, typography, animations, responsive grid
    │   └── admin.css           # Admin dashboard layout, tables, and metric cards
    ├── js/
    │   ├── store.js            # Central reactive store: cart, products, currencies, orders
    │   ├── main.js             # UI controller: Cart drawer, header, currency sync, toasts
    │   ├── discovery.js        # Interactive quiz engine & scent matching algorithm
    │   ├── checkout.js         # Checkout multi-step flow & order generator
    │   └── admin.js            # Admin dashboard logic with session verification & API sync
    └── images/
        ├── logo.jpg            # Official MOLN V brand logo asset
        ├── logo.png            # Converted PNG format for responsive rendering
        ├── brand-palette.jpg   # Official brand color reference
        ├── hero-perfume-editorial.svg # Cinematic hero banner
        ├── discovery-banner.svg# Olfactory diagram banner
        ├── craftsmanship-banner.svg # Architectural craftsmanship banner
        ├── perfumes/           # High-resolution vector flacons for Editions I–V & Discovery Set
        └── icons/              # Vector payment icons (Mada, Apple Pay, Tabby, Tamara, Visa, MC)
```

---

## How to Preview & Run Locally

### Option 1: Using the Included Secure Python Server (Recommended)
Run the following in your terminal:
```bash
python3 server.py
```
Then open your browser to:
- **Public Storefront:** [http://localhost:8000](http://localhost:8000)
- **Fragrance Catalog:** [http://localhost:8000/shop.html](http://localhost:8000/shop.html)
- **Scent Finder Quiz:** [http://localhost:8000/discovery.html](http://localhost:8000/discovery.html)
- **Customer Account Portal:** [http://localhost:8000/account.html](http://localhost:8000/account.html)
- **Admin Management Portal:** [http://localhost:8000/admin.html](http://localhost:8000/admin.html) *(Requires server-side login)*

### Option 2: Static Hosting Deployment
All customer-facing pages use relative asset paths and function fully on static hosting (e.g. GitHub Pages, Vercel). On static hosting, visiting `admin.html` displays an HTTP 403 Access Denied security screen, ensuring that administrative controls remain strictly protected until linked to an authorized backend authentication service.

---

## GitHub Pages Deployment Guide

The website is fully configured and tested for GitHub Pages project sites under the repository subpath:
`https://kareemsalem506-collab.github.io/-MOLN-.-V-/`

### Key Requirements Verified:
1. **No Absolute Root Paths:** All links, stylesheets, scripts, and image references use relative paths (`assets/css/style.css`, `assets/js/...`, `shop.html`), allowing seamless execution under any subpath like `/-MOLN-.-V-/`.
2. **`.nojekyll` Included:** An empty `.nojekyll` file is located in the repository root to disable Jekyll processing, ensuring all static files and folders are served directly without missing files.
3. **Exact Case Sensitivity:** All directory and file names match their HTML/CSS/JS references exactly.
4. **404 Auto-Resolution:** `404.html` includes an auto-base script to correctly resolve assets under `/-MOLN-.-V-/`.

### How to Upload to GitHub:

#### Method A: Using Git (Recommended & Instant)
Run the following commands in your terminal:
```bash
cd "/Users/karem/Downloads/موقع شوبي فاي "
git init
git remote add origin https://github.com/kareemsalem506-collab/-MOLN-.-V-.git
git branch -M main
git add .
git commit -m "Deploy complete MOLN V website with full assets"
git push -u origin main --force
```

#### Method B: Using GitHub Web Upload
1. Open your repository at `https://github.com/kareemsalem506-collab/-MOLN-.-V-`.
2. Open the local project folder: `/Users/karem/Downloads/موقع شوبي فاي `.
3. Select **all items inside this folder** (all `.html` files, `.nojekyll`, and crucially the **`assets`** folder).
4. Drag and drop them directly into the GitHub web uploader and commit.
5. **Important:** Ensure the contents are placed in the **repository root**, not inside an extra parent folder.
