# MOLN V — Pre-Launch Checklist & Commerce Platform Roadmap

This document serves as the strategic transition and operational checklist for the brand owner of **MOLN V** prior to commercial launch in Saudi Arabia and the GCC.

---

## 1. Platform Recommendation & Cost Analysis

The project workspace is named `موقع شوبي فاي` (*Shopify Website*). For a new luxury fragrance brand targeting customers across Saudi Arabia and the GCC with no pre-existing infrastructure, our strategic recommendation is:

### Primary Recommendation: **Shopify (Basic or Shopify Plan)**

| Feature | Shopify Assessment | Ongoing Cost Estimate |
| :--- | :--- | :--- |
| **Platform Subscription** | Shopify Basic | **\$39 / month** (or \$29/mo billed annually) |
| **Domain Name** | Custom domain (`molnv.com` or `molnvfragrances.com`) | **\$14 – \$20 / year** |
| **Payment Gateway Integration** | Native support for Mada, Apple Pay, Tabby, Tamara via Gulf aggregators | 2.5% to 2.9% + 1.00 SAR per transaction |
| **Tabby / Tamara BNPL** | Pre-built Shopify apps for 1-click install | ~5.0% to 6.5% per completed split order |
| **Hosting & SSL** | Unlimited bandwidth, global CDN, 99.99% uptime | **Included free** in Shopify plan |
| **Total Estimated Fixed Launch Cost** | Minimal startup overhead | **~\$55 – \$75 total to get live** |

#### Why Shopify Over Other Platforms?
1. **Unmatched Mobile Conversion:** Shopify’s checkout converts up to 36% better than custom self-hosted checkouts and is fully optimized for **Apple Pay** and **Mada** with one-tap biometric authentication.
2. **GCC Localization Support:** Supports automated currency conversions (SAR, AED, KWD, QAR, BHD, OMR) and multi-language capabilities.
3. **No DevOps Maintenance:** Unlike WordPress/WooCommerce, there are no database crashes, security patching, or hosting bottlenecks during peak marketing campaigns or influencer launches.
4. **Alternative Consideration (Salla / Zid):** Salla is dominant within Saudi Arabia for local merchants, but Shopify offers far superior editorial luxury aesthetics (like Amouage and international niche fragrance houses) and smoother multi-country cross-border selling across UAE, Kuwait, and Qatar.

---

## 2. Brand Owner Pre-Launch Action Items

Before taking the website live to customers, the brand owner must supply or configure the following items:

### A. Brand Assets & Photography
- [ ] **High-Resolution Photography:** Replace vector bottle illustrations with professional studio photography of physical 100ml flacons and the Discovery Wardrobe coffret (plain white/black backgrounds + editorial lifestyle shots).
- [ ] **Exact Olfactory Formulas:** Review and confirm the authentic Top Notes, Heart Notes, and Base Notes for Editions I through V in the catalog.
- [ ] **Founder / Atelier Story:** Replace the draft text in `about.html` with your official founding narrative, master perfumer biography, or inspiration statement.

### B. Payment Provider Onboarding
*Note: Do not imply a payment provider is connected until commercial merchant accounts are approved.*
- [ ] **Saudi Commercial Registration (CR) or Freelance Certificate (وثيقة العمل الحر):** Required to accept online payments in Saudi Arabia.
- [ ] **Saudi Payment Gateway Account:** Register with an authorized payment aggregator:
  - **Moyasar**, **Tap Payments**, **PayTabs**, or **Checkout.com** (to activate Mada, Visa, Mastercard, and Apple Pay).
- [ ] **Tabby & Tamara Merchant Accounts:**
  - Apply at [partner.tabby.ai](https://partner.tabby.ai) and [tamara.co/partners](https://tamara.co/partners) to obtain API keys for 4-installment buy-now-pay-later checkout.

### C. Logistics & Courier Partnerships
- [ ] **Courier Accounts:** Contract with regional GCC temperature-controlled couriers (e.g., **SMSA Express**, **Aramex**, **DHL Express**, or **Saudi Post SPL**).
- [ ] **Fulfillment Rules:** Set final flat shipping rates in the Admin Console (e.g., Free over 500 SAR, 30 SAR standard within KSA, 45 SAR to UAE/Kuwait).
- [ ] **Return Pickup Workflow:** Establish the procedure for couriers to retrieve damaged or incorrect orders.

### D. Legal & Policy Reviews
- [ ] **Shipping Policy:** Review and finalize timelines in `shipping-policy.html`.
- [ ] **Refund Policy:** Confirm that sealed cellophane requirements in `refund-policy.html` align with your local Ministry of Commerce regulations.
- [ ] **VAT Registration:** If annual taxable sales exceed 375,000 SAR, register with ZATCA (Zakat, Tax and Customs Authority) and ensure tax invoice compliance.

### E. Customer Service & Concierge Setup
- [ ] **WhatsApp Business Account:** Register a dedicated phone line with WhatsApp Business. Update the number in `admin.html` (e.g., `96650XXXXXXX`).
- [ ] **Support Email:** Create `concierge@molnv.com` on your custom domain email provider (e.g., Google Workspace or Zoho Mail).

---

## 3. Technical Verification & Launch Testing Checklist

Before the first public sale:
1. **Test Order Flow:** Perform an end-to-end test order through `shop.html` → `product.html` → `cart.html` → `checkout.html` → `order-confirmation.html`.
2. **Currency Conversion Verification:** Switch between SAR, AED, KWD, QAR, BHD, and OMR in the header dropdown to ensure prices recalculate cleanly.
3. **Responsive Mobile Testing:** Test on iOS Safari and Android Chrome to verify the **Sticky Mobile Add-to-Cart bar** and slide-out cart drawer.
4. **WhatsApp Link Test:** Tap the floating WhatsApp button to confirm it opens WhatsApp with the pre-filled inquiry text.
5. **Admin Console Security Verification:** Launch `python3 server.py` and test logging into `/admin.html` with authorized administrator credentials. Verify that unauthenticated visitors receive HTTP 401 Unauthorized, that customer accounts receive HTTP 403 Forbidden, and that static deployments serve a 403 Access Denied lockdown page.
