/**
 * MOLN V — ATELIER CONSOLE CONTROLLER
 * Requires authenticated server-side administrator session.
 * Unauthenticated requests or customer accounts are strictly blocked.
 * Zero credentials or client secrets stored in code.
 */

class AdminController {
  constructor(adminUser) {
    this.adminUser = adminUser || 'Admin';
    this.currentTab = 'dashboard';
    this.serverOrders = [];
    this.serverInquiries = [];
    this.serverSettings = null;
    this.init();
  }

  async init() {
    this.bindNavigation();
    await this.fetchServerData();
    this.renderDashboard();
    this.renderProducts();
    this.renderOrders();
    this.renderInquiries();
    this.renderSettings();
    this.bindProductModal();
    this.bindSettingsForm();

    window.addEventListener('moln_store_update', () => {
      this.renderDashboard();
      this.renderProducts();
      this.renderOrders();
      this.renderInquiries();
    });
  }

  async fetchServerData() {
    try {
      const [ordersRes, inqRes, setRes] = await Promise.all([
        fetch('/api/admin/orders', { cache: 'no-store' }),
        fetch('/api/admin/inquiries', { cache: 'no-store' }),
        fetch('/api/admin/settings', { cache: 'no-store' })
      ]);

      if (ordersRes.ok) this.serverOrders = await ordersRes.json();
      if (inqRes.ok) this.serverInquiries = await inqRes.json();
      if (setRes.ok) this.serverSettings = await setRes.json();
    } catch (e) {
      console.warn('[Admin] Server data sync unavailable, fallback to local storage');
    }
  }

  bindNavigation() {
    document.querySelectorAll('.admin-nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        const tab = item.getAttribute('data-tab');
        if (!tab) return;
        this.switchTab(tab);
      });
    });
  }

  switchTab(tabName) {
    this.currentTab = tabName;
    document.querySelectorAll('.admin-nav-item').forEach(item => {
      if (item.getAttribute('data-tab') === tabName) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    document.querySelectorAll('.admin-tab-view').forEach(view => {
      if (view.getAttribute('id') === `view-${tabName}`) {
        view.style.display = 'block';
      } else {
        view.style.display = 'none';
      }
    });
  }

  renderDashboard() {
    const orders = this.serverOrders.length > 0 ? this.serverOrders : (window.molnStore?.getOrders() || []);
    const products = window.molnStore?.getProducts() || [];
    const inquiries = this.serverInquiries.length > 0 ? this.serverInquiries : (window.molnStore?.getInquiries() || []);

    const totalRevenueSAR = orders.reduce((sum, o) => sum + (o.totalSAR || 0), 0);
    const avgOrderSAR = orders.length > 0 ? (totalRevenueSAR / orders.length) : 0;

    const revEl = document.getElementById('stat-revenue');
    const ordersEl = document.getElementById('stat-orders');
    const aovEl = document.getElementById('stat-aov');
    const inqEl = document.getElementById('stat-inquiries');

    if (revEl && window.molnStore) revEl.textContent = window.molnStore.formatPrice(totalRevenueSAR);
    if (ordersEl) ordersEl.textContent = orders.length;
    if (aovEl && window.molnStore) aovEl.textContent = window.molnStore.formatPrice(avgOrderSAR);
    if (inqEl) inqEl.textContent = inquiries.length;

    // Render Recent Orders in dashboard
    const recentOrdersContainer = document.getElementById('dashboard-recent-orders');
    if (recentOrdersContainer) {
      if (orders.length === 0) {
        recentOrdersContainer.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--admin-text-muted); padding: 2rem;">No customer orders placed yet.</td></tr>';
      } else {
        const recent = orders.slice(0, 5);
        recentOrdersContainer.innerHTML = recent.map(o => `
          <tr>
            <td><strong>${o.id}</strong></td>
            <td>${o.date}</td>
            <td>${o.customer?.name || 'Customer'}</td>
            <td>${o.customer?.city || 'GCC'}, ${o.customer?.country || ''}</td>
            <td><strong>${window.molnStore ? window.molnStore.formatPrice(o.totalSAR) : o.totalSAR + ' SAR'}</strong></td>
            <td><span class="badge ${this.getStatusBadgeClass(o.status)}">${o.status}</span></td>
          </tr>
        `).join('');
      }
    }
  }

  renderProducts() {
    if (!window.molnStore) return;
    const products = window.molnStore.getProducts();
    const tableBody = document.getElementById('admin-products-table-body');
    if (!tableBody) return;

    tableBody.innerHTML = products.map(p => `
      <tr>
        <td>
          <div style="display: flex; align-items: center; gap: 0.85rem;">
            <img src="${p.image}" alt="${p.name}" style="width: 44px; height: 52px; object-fit: contain; background: #000; border-radius: 4px; border: 1px solid var(--color-border);">
            <div>
              <div style="font-weight: 600; color: #fff;">${p.name}</div>
              <div style="font-size: 0.75rem; color: var(--color-powder-blue);">${p.subtitle}</div>
            </div>
          </div>
        </td>
        <td>${p.family}</td>
        <td><strong>${window.molnStore.formatPrice(p.priceSAR)}</strong></td>
        <td>
          <span class="badge ${p.stock > 20 ? 'badge-success' : (p.stock > 0 ? 'badge-warning' : 'badge-danger')}">
            ${p.stock} in stock
          </span>
        </td>
        <td><span class="badge badge-info">${p.badge}</span></td>
        <td>
          <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-secondary btn-sm" onclick="window.adminInstance.openEditProductModal('${p.id}')">Edit</button>
            <button class="btn btn-outline btn-sm" style="color: #ef4444; border-color: rgba(239, 68, 68, 0.4);" onclick="window.adminInstance.deleteProduct('${p.id}')">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  renderOrders() {
    const orders = this.serverOrders.length > 0 ? this.serverOrders : (window.molnStore?.getOrders() || []);
    const tableBody = document.getElementById('admin-orders-table-body');
    if (!tableBody) return;

    if (orders.length === 0) {
      tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--admin-text-muted); padding: 2.5rem;">No customer orders placed yet. Orders will appear here upon checkout.</td></tr>';
      return;
    }

    tableBody.innerHTML = orders.map(o => `
      <tr>
        <td><strong>${o.id}</strong></td>
        <td>${o.date}</td>
        <td>
          <div><strong>${o.customer?.name}</strong></div>
          <div style="font-size: 0.75rem; color: var(--admin-text-muted);">${o.customer?.phone} • ${o.customer?.city}</div>
        </td>
        <td>
          <div style="font-size: 0.78rem;">
            ${(o.items || []).map(i => `${i.name} (×${i.qty})`).join(', ')}
          </div>
        </td>
        <td><strong>${window.molnStore ? window.molnStore.formatPrice(o.totalSAR) : o.totalSAR + ' SAR'}</strong></td>
        <td>
          <select class="form-control" style="padding: 0.25rem 0.5rem; font-size: 0.78rem;" onchange="window.adminInstance.updateOrderStatus('${o.id}', this.value)">
            <option value="Processing" ${o.status === 'Processing' ? 'selected' : ''}>Processing</option>
            <option value="In Transit" ${o.status === 'In Transit' ? 'selected' : ''}>In Transit</option>
            <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
            <option value="Cancelled" ${o.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
          </select>
        </td>
      </tr>
    `).join('');
  }

  async updateOrderStatus(orderId, newStatus) {
    if (window.molnStore) {
      window.molnStore.updateOrderStatus(orderId, newStatus);
    }
    try {
      await fetch('/api/admin/orders/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: orderId, status: newStatus })
      });
    } catch (e) {}
    if (window.showToast) window.showToast(`Order ${orderId} status updated to ${newStatus}`, '✓');
  }

  renderInquiries() {
    const inquiries = this.serverInquiries.length > 0 ? this.serverInquiries : (window.molnStore?.getInquiries() || []);
    const container = document.getElementById('admin-inquiries-list');
    if (!container) return;

    if (inquiries.length === 0) {
      container.innerHTML = `<p style="color: var(--admin-text-muted); text-align: center; padding: 2rem;">No customer inquiries in inbox yet.</p>`;
      return;
    }

    container.innerHTML = inquiries.map(inq => `
      <div style="background: rgba(214, 230, 243, 0.03); border: 1px solid var(--color-border); border-radius: 6px; padding: 1.25rem; margin-bottom: 1rem;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
          <div>
            <h4 style="color: #fff; font-size: 1rem; margin-bottom: 0.25rem;">${inq.subject}</h4>
            <div style="font-size: 0.78rem; color: var(--color-powder-blue);">From: <strong>${inq.name}</strong> (${inq.email} • ${inq.phone || 'No phone'}) on ${inq.date}</div>
          </div>
          <span class="badge ${inq.status === 'New' ? 'badge-warning' : 'badge-success'}">${inq.status}</span>
        </div>
        <p style="font-size: 0.88rem; color: var(--color-ice-blue); line-height: 1.6; background: rgba(0,0,0,0.25); padding: 0.75rem; border-radius: 4px;">
          "${inq.message}"
        </p>
        <div style="margin-top: 0.75rem; display: flex; gap: 0.75rem;">
          <a href="mailto:${inq.email}?subject=Reply: ${encodeURIComponent(inq.subject)}" class="btn btn-secondary btn-sm">Reply via Email</a>
          ${inq.phone ? `<a href="https://wa.me/${inq.phone.replace(/[^0-9]/g, '')}?text=Hello ${encodeURIComponent(inq.name)}, regarding your inquiry with MOLN V..." target="_blank" class="btn btn-outline btn-sm">WhatsApp Client</a>` : ''}
        </div>
      </div>
    `).join('');
  }

  renderSettings() {
    const settings = this.serverSettings || (window.molnStore?.getSettings() || {});
    const form = document.getElementById('admin-settings-form');
    if (!form) return;

    if (document.getElementById('setting-store-name')) document.getElementById('setting-store-name').value = settings.storeName || 'MOLN V';
    if (document.getElementById('setting-announcement')) document.getElementById('setting-announcement').value = settings.announcementText || '';
    if (document.getElementById('setting-email')) document.getElementById('setting-email').value = settings.contactEmail || '';
    if (document.getElementById('setting-phone')) document.getElementById('setting-phone').value = settings.contactPhone || '';
    if (document.getElementById('setting-whatsapp')) document.getElementById('setting-whatsapp').value = settings.whatsappNumber || '';
    if (document.getElementById('setting-free-shipping')) document.getElementById('setting-free-shipping').value = settings.freeShippingThresholdSAR || 500;
  }

  bindSettingsForm() {
    const form = document.getElementById('admin-settings-form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const settings = {
          storeName: document.getElementById('setting-store-name').value.trim(),
          announcementText: document.getElementById('setting-announcement').value.trim(),
          contactEmail: document.getElementById('setting-email').value.trim(),
          contactPhone: document.getElementById('setting-phone').value.trim(),
          whatsappNumber: document.getElementById('setting-whatsapp').value.trim(),
          freeShippingThresholdSAR: parseFloat(document.getElementById('setting-free-shipping').value) || 500
        };

        if (window.molnStore) {
          window.molnStore.saveSettings(settings);
        }

        try {
          await fetch('/api/admin/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
          });
        } catch (err) {}

        if (window.showToast) window.showToast('Store settings saved successfully', '✓');
      });
    }
  }

  bindProductModal() {
    const openAddBtn = document.getElementById('btn-open-add-product');
    const modal = document.getElementById('admin-product-modal');
    const closeBtn = document.getElementById('btn-close-product-modal');
    const form = document.getElementById('admin-product-form');

    if (openAddBtn && modal) {
      openAddBtn.addEventListener('click', () => {
        form.reset();
        document.getElementById('modal-product-id').value = '';
        document.getElementById('modal-title').textContent = 'Add New Fragrance Edition';
        modal.classList.add('active');
      });
    }

    if (closeBtn && modal) {
      closeBtn.addEventListener('click', () => {
        modal.classList.remove('active');
      });
    }

    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const id = document.getElementById('modal-product-id').value;
        const name = document.getElementById('modal-p-name').value.trim();
        const subtitle = document.getElementById('modal-p-subtitle').value.trim();
        const priceSAR = parseFloat(document.getElementById('modal-p-price').value) || 400;
        const stock = parseInt(document.getElementById('modal-p-stock').value) || 20;
        const family = document.getElementById('modal-p-family').value.trim();
        const badge = document.getElementById('modal-p-badge').value.trim() || 'Signature';
        const topNotes = document.getElementById('modal-p-top').value.trim();
        const heartNotes = document.getElementById('modal-p-heart').value.trim();
        const baseNotes = document.getElementById('modal-p-base').value.trim();
        const description = document.getElementById('modal-p-desc').value.trim();

        if (!window.molnStore) return;

        if (id) {
          window.molnStore.updateProduct(id, {
            name, subtitle, priceSAR, stock, family, badge, topNotes, heartNotes, baseNotes, description
          });
          if (window.showToast) window.showToast(`Updated ${name}`, '✓');
        } else {
          const newId = `moln-v-${Date.now()}`;
          window.molnStore.addProduct({
            id: newId,
            name,
            subtitle,
            priceSAR,
            volume: '100ml Extrait de Parfum',
            stock,
            family,
            badge,
            topNotes,
            heartNotes,
            baseNotes,
            description,
            image: 'assets/images/perfumes/moln-v-no-1.svg',
            featured: true
          });
          if (window.showToast) window.showToast(`Added ${name} to catalog`, '✓');
        }

        modal.classList.remove('active');
      });
    }
  }

  openEditProductModal(id) {
    if (!window.molnStore) return;
    const product = window.molnStore.getProductById(id);
    if (!product) return;

    document.getElementById('modal-product-id').value = product.id;
    document.getElementById('modal-p-name').value = product.name;
    document.getElementById('modal-p-subtitle').value = product.subtitle || '';
    document.getElementById('modal-p-price').value = product.priceSAR;
    document.getElementById('modal-p-stock').value = product.stock;
    document.getElementById('modal-p-family').value = product.family;
    document.getElementById('modal-p-badge').value = product.badge;
    document.getElementById('modal-p-top').value = product.topNotes || '';
    document.getElementById('modal-p-heart').value = product.heartNotes || '';
    document.getElementById('modal-p-base').value = product.baseNotes || '';
    document.getElementById('modal-p-desc').value = product.description || '';

    document.getElementById('modal-title').textContent = `Edit Fragrance: ${product.name}`;
    document.getElementById('admin-product-modal').classList.add('active');
  }

  deleteProduct(id) {
    if (confirm('Are you sure you want to delete this fragrance edition?')) {
      if (window.molnStore) {
        window.molnStore.deleteProduct(id);
      }
      if (window.showToast) window.showToast('Fragrance edition removed', '✓');
    }
  }

  getStatusBadgeClass(status) {
    switch(status) {
      case 'Delivered': return 'badge-success';
      case 'Processing': return 'badge-info';
      case 'In Transit': return 'badge-warning';
      case 'Cancelled': return 'badge-danger';
      default: return 'badge-info';
    }
  }
}

// STRICT SERVER-SIDE SESSION VERIFICATION GATE
document.addEventListener('DOMContentLoaded', async () => {
  if (!document.body.classList.contains('admin-body')) {
    return;
  }

  try {
    const res = await fetch('/api/admin/session', { cache: 'no-store' });
    if (!res.ok) {
      window.location.href = '/admin.html';
      return;
    }
    const session = await res.json();
    if (!session || !session.authenticated || session.role !== 'admin') {
      console.warn('[MOLN V Security] Access Denied: Unauthenticated or non-admin role');
      window.location.href = '/admin.html';
      return;
    }

    // Authenticated admin verified
    window.adminInstance = new AdminController(session.user);
  } catch (err) {
    console.error('[MOLN V Security] Server session verification error:', err);
    window.location.href = '/admin.html';
  }
});
