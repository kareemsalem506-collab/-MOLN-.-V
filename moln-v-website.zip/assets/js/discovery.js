/**
 * MOLN V — INTERACTIVE FRAGRANCE DISCOVERY QUIZ
 * Guides customers through personalized scent profiling to alleviate the uncertainty of online fragrance buying.
 */

class FragranceQuiz {
  constructor() {
    this.currentStep = 1;
    this.totalSteps = 3;
    this.answers = {};
    this.init();
  }

  init() {
    this.bindEvents();
    this.updateUI();
  }

  bindEvents() {
    // Option clicks
    document.querySelectorAll('.quiz-option-card').forEach(card => {
      card.addEventListener('click', (e) => {
        const stepEl = card.closest('.quiz-step');
        if (!stepEl) return;

        const stepNum = parseInt(stepEl.getAttribute('data-step'));
        const value = card.getAttribute('data-value');

        // highlight selected
        stepEl.querySelectorAll('.quiz-option-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');

        this.answers[stepNum] = value;

        // Auto advance after slight delay for tactile feedback
        setTimeout(() => {
          if (stepNum < this.totalSteps) {
            this.goToStep(stepNum + 1);
          } else {
            this.calculateResult();
          }
        }, 250);
      });
    });

    // Back buttons
    document.querySelectorAll('.quiz-prev-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (this.currentStep > 1) {
          this.goToStep(this.currentStep - 1);
        }
      });
    });

    // Reset quiz
    document.querySelectorAll('.quiz-restart-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.reset();
      });
    });
  }

  goToStep(step) {
    this.currentStep = step;
    this.updateUI();
  }

  updateUI() {
    document.querySelectorAll('.quiz-step').forEach(stepEl => {
      const stepNum = parseInt(stepEl.getAttribute('data-step'));
      if (stepNum === this.currentStep) {
        stepEl.classList.add('active');
      } else {
        stepEl.classList.remove('active');
      }
    });

    // Update progress indicators if present
    const progressEl = document.querySelector('.quiz-step-indicator');
    if (progressEl) {
      progressEl.textContent = `Question ${this.currentStep} of ${this.totalSteps}`;
    }
  }

  calculateResult() {
    const q1 = this.answers[1]; // mood
    const q2 = this.answers[2]; // occasion
    const q3 = this.answers[3]; // projection

    let matchId = 'moln-v-01'; // default flagship

    if (q1 === 'fresh' || q2 === 'office') {
      matchId = 'moln-v-03'; // Frosted Cedar
    } else if (q1 === 'amber' || q2 === 'intimate') {
      matchId = 'moln-v-02'; // Nordic Amber
    } else if (q1 === 'oud' || q3 === 'imperial' || q2 === 'formal') {
      matchId = 'moln-v-04'; // Sovereign Oud
    } else if (q1 === 'chypre' || q3 === 'sublime') {
      matchId = 'moln-v-05'; // Signature Extrait
    } else if (q1 === 'sample') {
      matchId = 'moln-v-discovery';
    }

    const matchedProduct = window.molnStore.getProductById(matchId);
    this.showResult(matchedProduct);
  }

  showResult(product) {
    // Hide all question steps
    document.querySelectorAll('.quiz-step').forEach(el => el.classList.remove('active'));

    const resultContainer = document.querySelector('.quiz-result-container');
    if (!resultContainer) return;

    resultContainer.classList.add('active');
    resultContainer.innerHTML = `
      <div style="text-align: center; max-width: 650px; margin: 0 auto; animation: fadeIn 0.5s ease;">
        <span class="section-eyebrow">Your Olfactory Resonance</span>
        <h3 style="font-size: 2rem; color: #fff; margin-bottom: 0.5rem;">${product.name}</h3>
        <p style="color: var(--color-powder-blue); font-size: 0.95rem; margin-bottom: 1.75rem;">${product.subtitle}</p>

        <div style="background: rgba(0, 9, 38, 0.6); border: 1px solid var(--color-border); border-radius: 8px; padding: 2rem; margin-bottom: 2rem; text-align: left;">
          <div style="display: flex; gap: 1.5rem; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap;">
            <img src="${product.image}" alt="${product.name}" style="width: 110px; height: 135px; object-fit: contain; background: #000411; border-radius: 4px; border: 1px solid var(--color-border);">
            <div style="flex: 1; min-width: 220px;">
              <span class="badge badge-info" style="margin-bottom: 0.5rem;">${product.badge}</span>
              <p style="font-size: 0.9rem; color: var(--color-ice-blue); line-height: 1.6; margin-bottom: 0.75rem;">${product.description}</p>
              <div style="font-size: 1.35rem; font-weight: 700; color: #fff;">${window.molnStore.formatPrice(product.priceSAR)}</div>
              <div style="font-size: 0.75rem; color: var(--color-powder-blue);">Or 4 interest-free payments of ${window.molnStore.getInstallmentPrice(product.priceSAR)} with Tabby</div>
            </div>
          </div>

          <div style="border-top: 1px solid var(--color-border); padding-top: 1rem; font-size: 0.82rem; color: var(--color-slate-400);">
            <p><strong>Top Notes:</strong> ${product.topNotes}</p>
            <p style="margin-top: 4px;"><strong>Heart Notes:</strong> ${product.heartNotes}</p>
            <p style="margin-top: 4px;"><strong>Base Notes:</strong> ${product.baseNotes}</p>
          </div>
        </div>

        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
          <button class="btn btn-primary" onclick="window.molnStore.addToCart('${product.id}', 1); window.showToast('Added ${product.name} to shopping bag');">Add to Bag • ${window.molnStore.formatPrice(product.priceSAR)}</button>
          <a href="product.html?id=${product.id}" class="btn btn-secondary">Inspect Full Profile</a>
          <button class="btn btn-outline quiz-restart-btn" onclick="window.quizInstance.reset()">Retake Quiz</button>
        </div>

        <p style="font-size: 0.78rem; color: var(--color-slate-500); margin-top: 2rem;">
          Still uncertain? Try all 5 editions in the <a href="product.html?id=moln-v-discovery" style="color: var(--color-powder-blue); text-decoration: underline;">Discovery Wardrobe</a> with complimentary home delivery and a 100 SAR voucher.
        </p>
      </div>
    `;
  }

  reset() {
    this.currentStep = 1;
    this.answers = {};
    const resultContainer = document.querySelector('.quiz-result-container');
    if (resultContainer) {
      resultContainer.classList.remove('active');
      resultContainer.innerHTML = '';
    }
    document.querySelectorAll('.quiz-option-card').forEach(c => c.classList.remove('selected'));
    this.updateUI();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('.discovery-quiz-container')) {
    window.quizInstance = new FragranceQuiz();
  }
});
