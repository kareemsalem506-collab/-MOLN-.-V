/**
 * MOLN V — MAIN UI CONTROLLER & CART DRAWER
 * Handles Navigation, Header, Cart Drawer, Currencies, Toasts, and Global Events.
 */

document.addEventListener('DOMContentLoaded', () => {
  initSplashScreen();
  initHeader();
  initCartDrawer();
  initCurrencySelector();
  initWishlistInteractions();
  initToasts();
  updateHeaderBadges();
  renderCartDrawer();
  initWhatsAppFloating();
  syncAllWishlistButtons();

  // Listen for global store updates
  window.addEventListener('moln_store_update', (e) => {
    updateHeaderBadges();
    renderCartDrawer();
    syncAllWishlistButtons();
    if (e.detail.type === 'currency' || e.detail.type === 'all') {
      updatePagePrices();
    }
  });
});

// Toast notification helper
window.showToast = function(message, icon = '✦') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span style="color: var(--color-powder-blue);">${icon}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-20px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
};

// Header & Mobile Drawer
function initHeader() {
  const menuBtns = document.querySelectorAll('.menu-toggle-btn');
  const drawers = document.querySelectorAll('.mobile-nav-drawer');
  const closeBtns = document.querySelectorAll('.close-mobile-nav-btn');

  function openDrawer(drawer) {
    if (!drawer) return;
    drawer.classList.add('active');
    document.body.classList.add('mobile-menu-open');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer(drawer) {
    if (!drawer) return;
    drawer.classList.remove('active');
    document.body.classList.remove('mobile-menu-open');
    document.body.style.overflow = '';
  }

  menuBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const targetDrawer = document.querySelector('.mobile-nav-drawer');
      openDrawer(targetDrawer);
    });
  });

  closeBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const targetDrawer = btn.closest('.mobile-nav-drawer') || document.querySelector('.mobile-nav-drawer');
      closeDrawer(targetDrawer);
    });
  });

  drawers.forEach(drawer => {
    drawer.addEventListener('click', (e) => {
      if (e.target === drawer) {
        closeDrawer(drawer);
      }
    });

    // Close when clicking any navigation link inside drawer
    drawer.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        closeDrawer(drawer);
      });
    });
  });

  // Global Escape key support
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      drawers.forEach(d => closeDrawer(d));
      const overlay = document.querySelector('.cart-drawer-overlay');
      if (overlay && overlay.classList.contains('active')) {
        overlay.classList.remove('active');
        document.body.style.overflow = '';
      }
    }
  });
}

// Cart Drawer
function initCartDrawer() {
  const openBtns = document.querySelectorAll('.cart-open-btn');
  const overlay = document.querySelector('.cart-drawer-overlay');
  const closeBtn = document.querySelector('.close-drawer-btn');

  openBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (overlay) {
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  if (closeBtn && overlay) {
    closeBtn.addEventListener('click', () => {
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    });
  }

  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }
}

// Currency Selector Sync
function initCurrencySelector() {
  const selects = document.querySelectorAll('.currency-select');
  const current = window.molnStore.getCurrency();

  selects.forEach(select => {
    select.value = current;
    select.addEventListener('change', (e) => {
      window.molnStore.setCurrency(e.target.value);
      selects.forEach(s => s.value = e.target.value);
      window.showToast(`Currency updated to ${e.target.value}`);
    });
  });
}

// Update Badges in Header
function updateHeaderBadges() {
  if (!window.molnStore) return;
  const cartBadges = document.querySelectorAll('.cart-count-badge');
  const count = window.molnStore.getCartCount();
  cartBadges.forEach(badge => {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  });

  const wishlistBadges = document.querySelectorAll('.wishlist-count-badge');
  const wishCount = window.molnStore.getWishlist().length;
  wishlistBadges.forEach(badge => {
    badge.textContent = wishCount;
    badge.style.display = wishCount > 0 ? 'flex' : 'none';
  });
}

// Render Cart Drawer Contents
function renderCartDrawer() {
  const itemsContainer = document.querySelector('.cart-drawer-items');
  const subtotalEl = document.querySelector('.cart-drawer-subtotal');
  const progressText = document.querySelector('.free-shipping-text');
  const progressFill = document.querySelector('.free-shipping-fill');
  const tabbyPill = document.querySelector('.drawer-tabby-calc');

  if (!itemsContainer || !window.molnStore) return;

  const cart = window.molnStore.getCart();
  const settings = window.molnStore.getSettings();
  const subtotalSAR = window.molnStore.getCartSubtotalSAR();

  if (cart.length === 0) {
    itemsContainer.innerHTML = `
      <div style="text-align: center; padding: 4rem 1rem; color: var(--color-slate-400);">
        <svg style="margin: 0 auto 1.5rem; opacity: 0.4;" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <path d="M16 10a4 4 0 0 1-8 0"></path>
        </svg>
        <p style="font-family: var(--font-serif); font-size: 1.15rem; color: #fff; margin-bottom: 0.5rem;">Your shopping bag is empty</p>
        <p style="font-size: 0.85rem; margin-bottom: 1.75rem;">Discover our distinctive fragrances and begin your olfactory journey.</p>
        <a href="shop.html" class="btn btn-secondary btn-sm" onclick="document.querySelector('.cart-drawer-overlay').classList.remove('active')">Explore Fragrances</a>
      </div>
    `;
    if (subtotalEl) subtotalEl.textContent = window.molnStore.formatPrice(0);
    if (progressText) progressText.textContent = `Complimentary shipping on orders over ${window.molnStore.formatPrice(settings.freeShippingThresholdSAR)}`;
    if (progressFill) progressFill.style.width = '0%';
    if (tabbyPill) tabbyPill.textContent = '';
    return;
  }

  // Render Items
  itemsContainer.innerHTML = cart.map(item => `
    <div class="cart-item" data-id="${item.id}">
      <img src="${item.image}" alt="${item.name}" class="cart-item-img">
      <div class="cart-item-details">
        <div>
          <div class="cart-item-title">${item.name}</div>
          <div class="cart-item-meta">${item.volume}</div>
          <div class="cart-item-price" style="margin-top: 4px;">${window.molnStore.formatPrice(item.priceSAR * item.qty)}</div>
        </div>
        <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 0.75rem;">
          <div class="cart-qty-controls">
            <button class="qty-btn" onclick="window.molnStore.updateCartQty('${item.id}', -1)">−</button>
            <span class="qty-number">${item.qty}</span>
            <button class="qty-btn" onclick="window.molnStore.updateCartQty('${item.id}', 1)">+</button>
          </div>
          <button class="cart-item-remove" onclick="window.molnStore.removeFromCart('${item.id}')">Remove</button>
        </div>
      </div>
    </div>
  `).join('');

  // Subtotal & Installments
  if (subtotalEl) {
    subtotalEl.textContent = window.molnStore.formatPrice(subtotalSAR);
  }
  if (tabbyPill) {
    tabbyPill.innerHTML = `Or 4 interest-free payments of <strong>${window.molnStore.getInstallmentPrice(subtotalSAR)}</strong> with Tabby / Tamara`;
  }

  // Free shipping bar
  const threshold = settings.freeShippingThresholdSAR;
  const pct = Math.min(100, Math.round((subtotalSAR / threshold) * 100));
  if (progressFill) progressFill.style.width = `${pct}%`;

  if (progressText) {
    if (subtotalSAR >= threshold) {
      progressText.innerHTML = `✨ <strong>Congratulations!</strong> You qualify for complimentary GCC Express Shipping.`;
    } else {
      const remainingSAR = threshold - subtotalSAR;
      progressText.innerHTML = `Add <strong>${window.molnStore.formatPrice(remainingSAR)}</strong> more to unlock complimentary GCC shipping.`;
    }
  }
}

// Global update for prices in currently visible elements with data-price-sar
function updatePagePrices() {
  document.querySelectorAll('[data-price-sar]').forEach(el => {
    const sar = parseFloat(el.getAttribute('data-price-sar'));
    if (!isNaN(sar)) {
      el.textContent = window.molnStore.formatPrice(sar);
    }
  });

  document.querySelectorAll('[data-tabby-sar]').forEach(el => {
    const sar = parseFloat(el.getAttribute('data-tabby-sar'));
    if (!isNaN(sar)) {
      el.textContent = window.molnStore.getInstallmentPrice(sar);
    }
  });
}

// WhatsApp Concierge Link
function initWhatsAppFloating() {
  const btns = document.querySelectorAll('.whatsapp-floating-btn, a[href*="wa.me"]');
  const settings = window.molnStore.getSettings();
  let rawPhone = (settings.whatsappNumber || '201122983570').replace(/[^0-9]/g, '');
  if (rawPhone.startsWith('01') && rawPhone.length === 11) {
    rawPhone = '20' + rawPhone.substring(1);
  } else if (rawPhone.startsWith('05') && rawPhone.length === 10) {
    rawPhone = '966' + rawPhone.substring(1);
  }
  const defaultText = encodeURIComponent('Hello MOLN V Concierge, I would like to inquire about your distinctive fragrance collection.');
  btns.forEach(btn => {
    // Preserve custom text if already present in href, otherwise set default
    const existingUrl = btn.getAttribute('href') || '';
    if (existingUrl.includes('text=')) {
      const parts = existingUrl.split('text=');
      btn.href = `https://wa.me/${rawPhone}?text=${parts[1]}`;
    } else {
      btn.href = `https://wa.me/${rawPhone}?text=${defaultText}`;
    }
    btn.target = '_blank';
  });
}

function initToasts() {
  // ready
}

// Initial Visit Luxury Splash Screen Handler (Celestial Orbit Reveal)
function initSplashScreen() {
  const splash = document.getElementById('moln-splash-screen');
  if (!splash) return;

  // Immediate check for reduced motion or prior session visit
  const prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion || sessionStorage.getItem('moln_splash_shown') === 'true') {
    splash.remove();
    return;
  }

  // Already orchestrated by assets/js/splash.js
  if (typeof window.__molnDismissSplash === 'function') {
    return;
  }
}

// Global Wishlist Button Generator
window.renderWishlistButtonHtml = function(productId, extraClass = '') {
  const isIn = (window.molnStore && typeof window.molnStore.isInWishlist === 'function')
    ? window.molnStore.isInWishlist(productId)
    : false;
  const activeClass = isIn ? 'active' : '';
  const label = isIn ? 'Remove from favorites' : 'Add to favorites';
  const classes = `wishlist-btn ${activeClass} ${extraClass}`.trim();
  return `
    <button type="button" 
            class="${classes}" 
            data-product-id="${productId}" 
            aria-label="${label}" 
            title="${label}" 
            aria-pressed="${isIn ? 'true' : 'false'}">
      <svg class="wishlist-heart-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false">
        <path class="heart-path" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
      </svg>
    </button>
  `.trim();
};

// Global Wishlist Button Synchronization
function syncAllWishlistButtons(targetProductId = null, forceState = null) {
  if (!window.molnStore) return;
  const wishlist = window.molnStore.getWishlist();
  const selector = targetProductId 
    ? `.wishlist-btn[data-product-id="${targetProductId}"]` 
    : '.wishlist-btn[data-product-id]';

  const buttons = document.querySelectorAll(selector);
  buttons.forEach(btn => {
    const pId = btn.getAttribute('data-product-id');
    const isActive = (forceState !== null && pId === targetProductId) 
      ? forceState 
      : wishlist.includes(pId);

    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
    const label = isActive ? 'Remove from favorites' : 'Add to favorites';
    btn.setAttribute('aria-label', label);
    btn.setAttribute('title', label);
  });
}
window.syncAllWishlistButtons = syncAllWishlistButtons;

// Global Delegated Handler for Wishlist (Favorites) Button
function initWishlistInteractions() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.wishlist-btn');
    if (!btn) return;

    // Prevent navigation if the card or media is wrapped in or contains a link
    e.preventDefault();
    e.stopPropagation();

    const productId = btn.getAttribute('data-product-id') || btn.dataset.productId;
    if (!productId || !window.molnStore) return;

    // Toggle in store
    const isNowFavorite = window.molnStore.toggleWishlist(productId);

    // Synchronize all instances of this product across the current page
    syncAllWishlistButtons(productId, isNowFavorite);

    // Micro-animation bounce on clicked button
    btn.classList.remove('heart-pop');
    void btn.offsetWidth; // Force reflow
    btn.classList.add('heart-pop');

    // Visual confirmation toast
    const product = window.molnStore.getProductById(productId);
    const prodName = product ? product.name : 'Fragrance';
    if (isNowFavorite) {
      window.showToast(`${prodName} added to favorites`, '<span style="color: #FF3B5C;">♥</span>');
    } else {
      window.showToast(`${prodName} removed from favorites`, '<span style="color: var(--color-powder-blue);">♡</span>');
    }
  }, true); // Use capture to intercept click prior to any ancestor anchor / card navigation
}
