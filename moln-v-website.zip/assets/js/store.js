/**
 * MOLN V — CENTRAL STATE & COMMERCE STORE ENGINE
 * Manages Products, Cart, Wishlist, Currency conversions, GCC Shipping, Orders & Admin settings.
 * All state is persisted in localStorage with fallback to default catalog.
 */

const STORAGE_KEYS = {
  PRODUCTS: 'moln_v_products',
  CART: 'moln_v_cart',
  WISHLIST: 'moln_v_wishlist',
  CURRENCY: 'moln_v_current_currency',
  SETTINGS: 'moln_v_settings',
  ORDERS: 'moln_v_orders',
  INQUIRIES: 'moln_v_inquiries',
  DISCOVERY_RESULT: 'moln_v_discovery_result'
};

// Default GCC Currencies & Exchange rates (Base: SAR)
const CURRENCIES = {
  SAR: { code: 'SAR', symbol: 'SAR', rate: 1.0, name: 'Saudi Riyal (SAR)', decimals: 2 },
  AED: { code: 'AED', symbol: 'AED', rate: 0.98, name: 'UAE Dirham (AED)', decimals: 2 },
  KWD: { code: 'KWD', symbol: 'KWD', rate: 0.082, name: 'Kuwaiti Dinar (KWD)', decimals: 3 },
  QAR: { code: 'QAR', symbol: 'QAR', rate: 0.97, name: 'Qatari Riyal (QAR)', decimals: 2 },
  BHD: { code: 'BHD', symbol: 'BHD', rate: 0.10, name: 'Bahraini Dinar (BHD)', decimals: 3 },
  OMR: { code: 'OMR', symbol: 'OMR', rate: 0.10, name: 'Omani Rial (OMR)', decimals: 3 },
  USD: { code: 'USD', symbol: '$', rate: 0.27, name: 'US Dollar (USD)', decimals: 2 }
};

// Default Store Configuration
const DEFAULT_SETTINGS = {
  storeName: 'MOLN V',
  brandTagline: 'A premium fragrance house creating distinctive, refined perfumes.',
  announcementText: 'Complimentary express delivery across the GCC on orders over 500 SAR • Try at home with the Discovery Wardrobe',
  contactEmail: 'concierge@molnv.com [Placeholder]',
  contactPhone: '+20 11 2298 3570',
  whatsappNumber: '201122983570', // International format for 01122983570
  currencyDefault: 'SAR',
  freeShippingThresholdSAR: 500,
  shippingRates: {
    saudi: { standard: 30, express: 55 },
    uae: { standard: 40, express: 70 },
    gcc: { standard: 50, express: 85 }
  },
  taxRatePercent: 15, // Standard GCC VAT
  enableTabby: true,
  enableTamara: true,
  enableMada: true,
  enableApplePay: true,
  enableCod: true
};

// Initial Signature Products with Clearly Marked Editable Placeholders
const DEFAULT_PRODUCTS = [
  {
    id: 'moln-v-01',
    name: 'MOLN V — Edition I',
    edition: 'Edition I',
    subtitle: 'Sapphire Noir [Placeholder Name]',
    priceSAR: 420,
    volume: '100ml Extrait de Parfum',
    badge: 'Flagship Signature',
    image: 'assets/images/perfumes/moln-v-no-1.svg',
    family: 'Woody Oriental',
    sillage: 'Strong (8-12 Hours)',
    gender: 'Unisex / Contemporary',
    topNotes: 'Crisp Bergamot, Frosted Juniper, Pink Pepper [Placeholder]',
    heartNotes: 'Nordic Cedarwood, Florence Iris, Smoked Amber [Placeholder]',
    baseNotes: 'Smoked Incense, Rich Patchouli, Deep Sovereign Musk [Placeholder]',
    description: 'An architectural collision of icy Nordic clarity and sovereign Gulf warmth. Opens with crisp aromatic freshness before unveiling a heart of Florentine iris and aged cedarwood, settling into a hypnotic base of smoked incense and musk.',
    philosophy: 'Designed for the individual who rejects predictable sweetness in favor of profound, commanding elegance.',
    stock: 45,
    featured: true,
    tags: ['woody', 'oriental', 'evening', 'bestseller']
  },
  {
    id: 'moln-v-02',
    name: 'MOLN V — Edition II',
    edition: 'Edition II',
    subtitle: 'Nordic Amber [Placeholder Name]',
    priceSAR: 390,
    volume: '100ml Extrait de Parfum',
    badge: 'Bestseller',
    image: 'assets/images/perfumes/moln-v-no-2.svg',
    family: 'Amber Gourmand',
    sillage: 'Moderate-to-Strong (10 Hours)',
    gender: 'Unisex',
    topNotes: 'Cardamom Infusion, Bitter Orange, Saffron Flakes [Placeholder]',
    heartNotes: 'Golden Ambergris, Tobacco Blossom, Cinnamon Bark [Placeholder]',
    baseNotes: 'Bourbon Vanilla Bean, Tonka, Velvety Sandalwood [Placeholder]',
    description: 'A comforting yet commanding aura of luminous amber. Crafted to wrap the wearer in an intoxicating sillage that feels both intimately personal and distinctly elevated.',
    philosophy: 'Strikes the delicate balance between decadent warmth and modern restraint.',
    stock: 32,
    featured: true,
    tags: ['amber', 'warm', 'gathering', 'fall-winter']
  },
  {
    id: 'moln-v-03',
    name: 'MOLN V — Edition III',
    edition: 'Edition III',
    subtitle: 'Frosted Cedar [Placeholder Name]',
    priceSAR: 380,
    volume: '100ml Extrait de Parfum',
    badge: 'Daylight Fresh',
    image: 'assets/images/perfumes/moln-v-no-3.svg',
    family: 'Fresh Aromatic Woody',
    sillage: 'Moderate (7-9 Hours)',
    gender: 'Unisex',
    topNotes: 'Glacial Mint, Sparkling Grapefruit, Sea Salt [Placeholder]',
    heartNotes: 'Atlas Cedar, Blue Lavender, Clary Sage [Placeholder]',
    baseNotes: 'Haitian Vetiver, Clean Oakmoss, White Cashmere Musk [Placeholder]',
    description: 'An invigorating blast of alpine clarity designed for professional daytime wear in warm Gulf climates. Clean, razor-sharp, and unforgettably crisp.',
    philosophy: 'Clean luxury that remains vibrant under the most demanding climates.',
    stock: 58,
    featured: true,
    tags: ['fresh', 'citrus', 'woody', 'day', 'office']
  },
  {
    id: 'moln-v-04',
    name: 'MOLN V — Edition IV',
    edition: 'Edition IV',
    subtitle: 'Sovereign Oud [Placeholder Name]',
    priceSAR: 480,
    volume: '100ml Extrait de Parfum',
    badge: 'Prestige Selection',
    image: 'assets/images/perfumes/moln-v-no-4.svg',
    family: 'Smoky Leather Oud',
    sillage: 'Enormous (12+ Hours)',
    gender: 'Unisex / Bold',
    topNotes: 'Persian Saffron, Wild Thyme, Smoked Raspberry [Placeholder]',
    heartNotes: 'Aged Cambodian Oud, Taif Rose Petals, Tuscan Leather [Placeholder]',
    baseNotes: 'Dark Amber, Birch Wood, Royal Civet Accords [Placeholder]',
    description: 'A rare celebration of sovereign heritage. Distilled from ethically aged wild agarwood and softened with rare Taif rose and hand-buffed leather accords.',
    philosophy: 'For formal majlis gatherings and evening occasions where presence must be felt without speaking.',
    stock: 20,
    featured: true,
    tags: ['oud', 'oriental', 'leather', 'evening', 'formal']
  },
  {
    id: 'moln-v-05',
    name: 'MOLN V — Edition V',
    edition: 'Edition V',
    subtitle: 'Signature Extrait [Placeholder Name]',
    priceSAR: 520,
    volume: '100ml Extrait de Parfum',
    badge: 'Limited Atelier',
    image: 'assets/images/perfumes/moln-v-no-5.svg',
    family: 'Complex Chypre',
    sillage: 'Sublime & Enduring (14+ Hours)',
    gender: 'Unisex',
    topNotes: 'Black Currant Nectar, Elemi Resin, Blood Mandarin [Placeholder]',
    heartNotes: 'French Narcissus, Night-Blooming Jasmine, Gaiac Wood [Placeholder]',
    baseNotes: 'Natural Gray Ambergris, Java Vetiver, Liquid Benzoin [Placeholder]',
    description: 'The pinnacle of MOLN V haute parfumerie. Concentrated at 32% oil density, each drop reveals an intricate evolution over hours on warm skin.',
    philosophy: 'A masterclass in modern niche perfumery for the true collector.',
    stock: 14,
    featured: true,
    tags: ['chypre', 'luxury', 'exclusive', 'bestseller']
  },
  {
    id: 'moln-v-discovery',
    name: 'MOLN V — The Discovery Wardrobe',
    edition: 'Set of 5',
    subtitle: 'Complete 5 × 10ml Coffret [Try At Home]',
    priceSAR: 210,
    volume: '5 × 10ml Extrait Atomizers',
    badge: 'Try Before Deciding',
    image: 'assets/images/perfumes/moln-v-discovery.svg',
    family: 'All Olfactory Families',
    sillage: 'Varies by edition',
    gender: 'Unisex',
    topNotes: 'Includes full 10ml flacons of Editions I, II, III, IV, and V.',
    heartNotes: 'Experience each signature on your skin across different times and moods.',
    baseNotes: 'Includes a 100 SAR voucher redeemable against any 100ml full bottle purchase.',
    description: 'We understand the hesitation of purchasing fine fragrance online without smelling it. The Discovery Wardrobe is our thoughtful solution: experience all five MOLN V editions in generous 10ml luxury atomizers, plus receive a 100 SAR credit code toward your favorite full-sized bottle.',
    philosophy: 'The antidote to online blind-buying uncertainty.',
    stock: 75,
    featured: true,
    tags: ['discovery', 'sample', 'gift', 'popular']
  }
];

// Customer Orders & Inquiries Start Completely Empty (No Mock Data)
const DEFAULT_ORDERS = [];
const DEFAULT_INQUIRIES = [];

class MolnStore {
  constructor() {
    this.initStorage();
  }

  initStorage() {
    if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(DEFAULT_PRODUCTS));
    } else {
      try {
        const stored = JSON.parse(localStorage.getItem(STORAGE_KEYS.PRODUCTS) || '[]');
        if (stored.some(s => s.image && s.image.includes('-bottle.png'))) {
          localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(DEFAULT_PRODUCTS));
        }
      } catch (e) {
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(DEFAULT_PRODUCTS));
      }
    }
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
    } else {
      try {
        const s = JSON.parse(localStorage.getItem(STORAGE_KEYS.SETTINGS));
        if (s && (s.whatsappNumber === '966501234567' || !s.whatsappNumber)) {
          s.whatsappNumber = '201122983570';
          s.contactPhone = '+20 11 2298 3570';
          localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(s));
        }
      } catch (e) {}
    }
    if (!localStorage.getItem(STORAGE_KEYS.ORDERS)) {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify([]));
    } else {
      // Purge any legacy sample orders
      try {
        const storedOrders = JSON.parse(localStorage.getItem(STORAGE_KEYS.ORDERS) || '[]');
        const cleanedOrders = storedOrders.filter(o => !['MOLN-7842', 'MOLN-7841', 'MOLN-7839'].includes(o.id));
        if (cleanedOrders.length !== storedOrders.length) {
          localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(cleanedOrders));
        }
      } catch (e) {}
    }
    if (!localStorage.getItem(STORAGE_KEYS.INQUIRIES)) {
      localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify([]));
    } else {
      // Purge any legacy sample inquiries
      try {
        const storedInqs = JSON.parse(localStorage.getItem(STORAGE_KEYS.INQUIRIES) || '[]');
        const cleanedInqs = storedInqs.filter(i => !['INQ-101', 'INQ-100'].includes(i.id));
        if (cleanedInqs.length !== storedInqs.length) {
          localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(cleanedInqs));
        }
      } catch (e) {}
    }
    if (!localStorage.getItem(STORAGE_KEYS.CART)) {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.WISHLIST)) {
      localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENCY)) {
      localStorage.setItem(STORAGE_KEYS.CURRENCY, 'SAR');
    }
  }

  // --- PRODUCTS ---
  getProducts() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.PRODUCTS)) || DEFAULT_PRODUCTS;
    } catch (e) {
      return DEFAULT_PRODUCTS;
    }
  }

  getProductById(id) {
    const products = this.getProducts();
    return products.find(p => p.id === id) || null;
  }

  saveProducts(products) {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.dispatchUpdate('products');
  }

  addProduct(product) {
    const products = this.getProducts();
    products.push(product);
    this.saveProducts(products);
  }

  updateProduct(id, updatedFields) {
    const products = this.getProducts();
    const index = products.findIndex(p => p.id === id);
    if (index !== -1) {
      products[index] = { ...products[index], ...updatedFields };
      this.saveProducts(products);
      return true;
    }
    return false;
  }

  deleteProduct(id) {
    let products = this.getProducts();
    products = products.filter(p => p.id !== id);
    this.saveProducts(products);
  }

  resetDefaultData() {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(DEFAULT_PRODUCTS));
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify([]));
    this.dispatchUpdate('all');
  }

  // --- CURRENCY CONVERSION ---
  getCurrency() {
    return localStorage.getItem(STORAGE_KEYS.CURRENCY) || 'SAR';
  }

  setCurrency(currencyCode) {
    if (CURRENCIES[currencyCode]) {
      localStorage.setItem(STORAGE_KEYS.CURRENCY, currencyCode);
      this.dispatchUpdate('currency');
    }
  }

  formatPrice(amountSAR, targetCurrencyCode = null) {
    const code = targetCurrencyCode || this.getCurrency();
    const cur = CURRENCIES[code] || CURRENCIES.SAR;
    const converted = amountSAR * cur.rate;
    const formatted = converted.toFixed(cur.decimals);
    return `${formatted} ${cur.symbol}`;
  }

  getInstallmentPrice(amountSAR, splits = 4) {
    const code = this.getCurrency();
    const cur = CURRENCIES[code] || CURRENCIES.SAR;
    const splitAmount = (amountSAR * cur.rate) / splits;
    return `${splitAmount.toFixed(cur.decimals)} ${cur.symbol}`;
  }

  // --- CART ---
  getCart() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.CART)) || [];
    } catch (e) {
      return [];
    }
  }

  saveCart(cart) {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    this.dispatchUpdate('cart');
  }

  addToCart(productId, qty = 1) {
    const product = this.getProductById(productId);
    if (!product) return false;

    let cart = this.getCart();
    const existingIndex = cart.findIndex(item => item.id === productId);

    if (existingIndex > -1) {
      cart[existingIndex].qty += qty;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        subtitle: product.subtitle,
        volume: product.volume,
        priceSAR: product.priceSAR,
        image: product.image,
        qty: qty
      });
    }

    this.saveCart(cart);
    return true;
  }

  updateCartQty(productId, delta) {
    let cart = this.getCart();
    const item = cart.find(i => i.id === productId);
    if (item) {
      item.qty += delta;
      if (item.qty <= 0) {
        cart = cart.filter(i => i.id !== productId);
      }
      this.saveCart(cart);
    }
  }

  removeFromCart(productId) {
    let cart = this.getCart();
    cart = cart.filter(i => i.id !== productId);
    this.saveCart(cart);
  }

  clearCart() {
    this.saveCart([]);
  }

  getCartCount() {
    const cart = this.getCart();
    return cart.reduce((sum, item) => sum + item.qty, 0);
  }

  getCartSubtotalSAR() {
    const cart = this.getCart();
    return cart.reduce((sum, item) => sum + (item.priceSAR * item.qty), 0);
  }

  // --- WISHLIST ---
  getWishlist() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.WISHLIST)) || [];
    } catch (e) {
      return [];
    }
  }

  toggleWishlist(productId) {
    let wishlist = this.getWishlist();
    const index = wishlist.indexOf(productId);
    let added = false;
    if (index > -1) {
      wishlist.splice(index, 1);
    } else {
      wishlist.push(productId);
      added = true;
    }
    localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
    this.dispatchUpdate('wishlist');
    return added;
  }

  isInWishlist(productId) {
    const wishlist = this.getWishlist();
    return wishlist.includes(productId);
  }

  // --- SETTINGS ---
  getSettings() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.SETTINGS)) || DEFAULT_SETTINGS;
    } catch (e) {
      return DEFAULT_SETTINGS;
    }
  }

  saveSettings(settings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    this.dispatchUpdate('settings');
  }

  // --- ORDERS ---
  getOrders() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.ORDERS)) || DEFAULT_ORDERS;
    } catch (e) {
      return DEFAULT_ORDERS;
    }
  }

  createOrder(orderData) {
    const orders = this.getOrders();
    const newOrder = {
      id: `MOLN-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      status: 'Processing',
      ...orderData
    };
    orders.unshift(newOrder);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    this.clearCart();
    this.dispatchUpdate('orders');
    return newOrder;
  }

  updateOrderStatus(orderId, newStatus) {
    const orders = this.getOrders();
    const order = orders.find(o => o.id === orderId);
    if (order) {
      order.status = newStatus;
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
      this.dispatchUpdate('orders');
      return true;
    }
    return false;
  }

  // --- INQUIRIES ---
  getInquiries() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.INQUIRIES)) || DEFAULT_INQUIRIES;
    } catch (e) {
      return DEFAULT_INQUIRIES;
    }
  }

  addInquiry(inquiry) {
    const inquiries = this.getInquiries();
    const newInquiry = {
      id: `INQ-${Math.floor(100 + Math.random() * 900)}`,
      date: new Date().toISOString().split('T')[0],
      status: 'New',
      ...inquiry
    };
    inquiries.unshift(newInquiry);
    localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(inquiries));
    this.dispatchUpdate('inquiries');
    return newInquiry;
  }

  // --- EVENT DISPATCHER ---
  dispatchUpdate(type) {
    window.dispatchEvent(new CustomEvent('moln_store_update', { detail: { type } }));
  }
}

// Global Store Instance
window.molnStore = new MolnStore();
