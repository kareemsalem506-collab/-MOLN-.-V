/**
 * MOLN V — HAUTE PARFUMERIE
 * Opening Experience: Refined Celestial Orbit Reveal (V & Orbiting Moons)
 * 
 * Choreography:
 * 0.00s - 0.25s : Clean, completely empty deep navy screen.
 * 0.25s - 0.95s : Central V symbol and all crescent moons fade in SIMULTANEOUSLY as one complete composition.
 * 0.95s - 2.45s : Moons glide gently and smoothly along circular orbits around the central V.
 * 2.45s - 3.10s : The V and moons fade out TOGETHER smoothly, revealing the homepage behind them.
 * ~3.10s        : Intro complete; splash element safely removed from DOM.
 */

(function () {
  'use strict';

  function initCelestialSplash() {
    var splash = document.getElementById('moln-splash-screen');
    if (!splash) return;

    // Accessibility & Session checks: never show again if seen, or if reduced-motion is requested
    var prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion || sessionStorage.getItem('moln_splash_shown') === 'true') {
      splash.remove();
      return;
    }

    var startTime = window.__splashStartTime || performance.now();
    var isDismissed = false;

    // Instant dismissal handler: allows immediate shopping access on any user interaction
    function dismissSplash(immediate) {
      if (isDismissed) return;
      isDismissed = true;
      sessionStorage.setItem('moln_splash_shown', 'true');
      splash.style.pointerEvents = 'none';

      if (immediate || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)) {
        splash.remove();
        return;
      }

      splash.classList.add('fade-out');
      setTimeout(function () {
        if (splash && splash.parentNode) {
          splash.remove();
        }
      }, 650);
    }

    // Expose dismiss handler globally
    window.__molnDismissSplash = dismissSplash;

    // Tap or click anywhere dismisses immediately so shopping is never delayed
    splash.addEventListener('click', function () {
      dismissSplash(true);
    });
    splash.addEventListener('touchstart', function () {
      dismissSplash(true);
    }, { passive: true });

    // Schedule simultaneous fade-out of V and moons to smoothly reveal homepage
    var elapsed = performance.now() - startTime;
    var remaining = Math.max(0, 2450 - elapsed);

    setTimeout(function () {
      dismissSplash(false);
    }, remaining);
  }

  // Execute immediately or on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCelestialSplash);
  } else {
    initCelestialSplash();
  }
})();
