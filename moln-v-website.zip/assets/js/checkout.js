/**
 * MOLN V — CHECKOUT CONTROLLER
 * 3-Step Gulf-optimized checkout flow with Address validation, shipping calculator, Tabby/Tamara/Mada/Apple Pay simulation.
 */

class CheckoutController {
  constructor() {
    this.currentStep = 1;
    this.discountCode = null;
    this.discountAmountSAR = 0;
    this.shippingCostSAR = 0;
    this.shippingMethod = 'GCC Express Air';
    this.paymentMethod = 'Apple Pay';
    this.formData = {};

    this.init();
  }

  init() {
    const cart = window.molnStore.getCart();
    if (cart.length === 0 && !window.location.href.includes('order-confirmation')) {
      // Empty cart redirect
      window.location.href = 'shop.html';
      return;
    }

    this.bindEvents();
    this.renderOrderSummary();
    this.updateShippingCost();
  }

  bindEvents() {
    // Step Navigation
    const step1Next = document.getElementById('step-1-next');
    if (step1Next) {
      step1Next.addEventListener('click', (e) => {
        e.preventDefault();
        if (this.validateStep1()) {
          this.goToStep(2);
        }
      });
    }

    const step2Next = document.getElementById('step-2-next');
    if (step2Next) {
      step2Next.addEventListener('click', (e) => {
        e.preventDefault();
        this.goToStep(3);
      });
    }

    const step2Back = document.getElementById('step-2-back');
    if (step2Back) {
      step2Back.addEventListener('click', () => this.goToStep(1));
    }

    const step3Back = document.getElementById('step-3-back');
    if (step3Back) {
      step3Back.addEventListener('click', () => this.goToStep(2));
    }

    // Shipping selection
    document.querySelectorAll('input[name="shipping_method"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.shippingMethod = e.target.value;
        this.updateShippingCost();
        this.renderOrderSummary();
      });
    });

    // Payment selection
    document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.paymentMethod = e.target.value;
        this.updatePaymentDetailsView(e.target.value);
      });
    });

    // Discount code apply
    const applyCouponBtn = document.getElementById('apply-coupon-btn');
    if (applyCouponBtn) {
      applyCouponBtn.addEventListener('click', () => {
        this.applyDiscount();
      });
    }

    // Final Place Order
    const placeOrderBtn = document.getElementById('place-order-btn');
    if (placeOrderBtn) {
      placeOrderBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.processFinalOrder();
      });
    }

    // Country change triggers shipping recalculation
    const countrySelect = document.getElementById('customer_country');
    if (countrySelect) {
      countrySelect.addEventListener('change', () => {
        this.updateShippingCost();
        this.renderOrderSummary();
      });
    }
  }

  goToStep(step) {
    this.currentStep = step;
    document.querySelectorAll('.checkout-step-panel').forEach(panel => {
      panel.classList.remove('active');
    });
    const target = document.getElementById(`checkout-step-${step}`);
    if (target) target.classList.add('active');

    // Update step numbers
    document.querySelectorAll('.step-indicator-pill').forEach(pill => {
      const pStep = parseInt(pill.getAttribute('data-step'));
      if (pStep === step) {
        pill.classList.add('current');
        pill.classList.remove('completed');
      } else if (pStep < step) {
        pill.classList.add('completed');
        pill.classList.remove('current');
      } else {
        pill.classList.remove('completed', 'current');
      }
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  validateStep1() {
    const name = document.getElementById('customer_name')?.value.trim();
    const email = document.getElementById('customer_email')?.value.trim();
    const phone = document.getElementById('customer_phone')?.value.trim();
    const city = document.getElementById('customer_city')?.value.trim();
    const address = document.getElementById('customer_address')?.value.trim();
    const country = document.getElementById('customer_country')?.value || 'Saudi Arabia';

    if (!name || !email || !phone || !city || !address) {
      window.showToast('Please complete all required delivery fields.', '⚠️');
      return false;
    }

    this.formData = {
      name, email, phone, city, address, country,
      district: document.getElementById('customer_district')?.value.trim() || '',
      nationalShortCode: document.getElementById('customer_shortcode')?.value.trim() || ''
    };

    return true;
  }

  updateShippingCost() {
    const subtotal = window.molnStore.getCartSubtotalSAR();
    const settings = window.molnStore.getSettings();

    if (subtotal >= settings.freeShippingThresholdSAR && this.shippingMethod !== 'Same-Day Courier') {
      this.shippingCostSAR = 0;
    } else {
      if (this.shippingMethod === 'Same-Day Courier') {
        this.shippingCostSAR = 55;
      } else if (this.shippingMethod === 'GCC Express Air') {
        this.shippingCostSAR = 45;
      } else {
        this.shippingCostSAR = 30;
      }
    }
  }

  applyDiscount() {
    const input = document.getElementById('coupon_code');
    if (!input) return;
    const code = input.value.trim().toUpperCase();
    const subtotal = window.molnStore.getCartSubtotalSAR();

    if (code === 'WELCOME10') {
      this.discountCode = 'WELCOME10 (10% Off)';
      this.discountAmountSAR = subtotal * 0.10;
      window.showToast('Promo code applied: 10% discount', '✨');
    } else if (code === 'DISCOVERY100') {
      this.discountCode = 'DISCOVERY100 (100 SAR Wardrobe Credit)';
      this.discountAmountSAR = Math.min(100, subtotal);
      window.showToast('Discovery voucher applied: 100 SAR deducted', '✨');
    } else {
      window.showToast('Invalid or expired promotional code', '⚠️');
      return;
    }

    this.renderOrderSummary();
  }

  updatePaymentDetailsView(method) {
    const cardFields = document.getElementById('credit-card-fields');
    const tabbyInfo = document.getElementById('tabby-info-box');
    const tamaraInfo = document.getElementById('tamara-info-box');

    if (cardFields) cardFields.style.display = (method === 'Mada' || method === 'Credit Card') ? 'block' : 'none';
    if (tabbyInfo) tabbyInfo.style.display = (method === 'Tabby') ? 'block' : 'none';
    if (tamaraInfo) tamaraInfo.style.display = (method === 'Tamara') ? 'block' : 'none';
  }

  renderOrderSummary() {
    const summaryContainer = document.getElementById('checkout-items-list');
    const subtotalEl = document.getElementById('summary-subtotal');
    const shippingEl = document.getElementById('summary-shipping');
    const discountEl = document.getElementById('summary-discount');
    const totalEl = document.getElementById('summary-total');
    const tabbySplitEl = document.getElementById('summary-tabby-split');

    if (!summaryContainer) return;

    const cart = window.molnStore.getCart();
    const subtotal = window.molnStore.getCartSubtotalSAR();

    summaryContainer.innerHTML = cart.map(item => `
      <div style="display: flex; gap: 1rem; align-items: center; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 1px solid var(--color-border);">
        <img src="${item.image}" alt="${item.name}" style="width: 50px; height: 60px; object-fit: contain; background: #000; border-radius: 4px; border: 1px solid var(--color-border);">
        <div style="flex: 1;">
          <div style="font-weight: 600; color: #fff; font-size: 0.88rem;">${item.name}</div>
          <div style="font-size: 0.75rem; color: var(--color-slate-400);">${item.volume} × ${item.qty}</div>
        </div>
        <div style="font-weight: 700; color: var(--color-ice-blue); font-size: 0.9rem;">
          ${window.molnStore.formatPrice(item.priceSAR * item.qty)}
        </div>
      </div>
    `).join('');

    const grandTotalSAR = Math.max(0, subtotal - this.discountAmountSAR + this.shippingCostSAR);

    if (subtotalEl) subtotalEl.textContent = window.molnStore.formatPrice(subtotal);
    if (shippingEl) {
      shippingEl.textContent = this.shippingCostSAR === 0 ? 'FREE (Complimentary GCC)' : window.molnStore.formatPrice(this.shippingCostSAR);
    }
    if (discountEl) {
      if (this.discountAmountSAR > 0) {
        discountEl.parentElement.style.display = 'flex';
        discountEl.textContent = `-${window.molnStore.formatPrice(this.discountAmountSAR)}`;
      } else {
        discountEl.parentElement.style.display = 'none';
      }
    }
    if (totalEl) totalEl.textContent = window.molnStore.formatPrice(grandTotalSAR);
    if (tabbySplitEl) {
      tabbySplitEl.innerHTML = `Or 4 payments of <strong>${window.molnStore.getInstallmentPrice(grandTotalSAR)}</strong> with Tabby / Tamara`;
    }
  }

  processFinalOrder() {
    const btn = document.getElementById('place-order-btn');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<span class="pulse-dot"></span> Securing Order...`;
    }

    const cart = window.molnStore.getCart();
    const subtotal = window.molnStore.getCartSubtotalSAR();
    const grandTotalSAR = Math.max(0, subtotal - this.discountAmountSAR + this.shippingCostSAR);

    setTimeout(() => {
      const order = window.molnStore.createOrder({
        customer: this.formData,
        items: cart,
        subtotalSAR: subtotal,
        discountSAR: this.discountAmountSAR,
        discountCode: this.discountCode,
        shippingCostSAR: this.shippingCostSAR,
        shippingMethod: this.shippingMethod,
        paymentMethod: this.paymentMethod,
        totalSAR: grandTotalSAR,
        currencyUsed: window.molnStore.getCurrency()
      });

      window.location.href = `order-confirmation.html?id=${order.id}`;
    }, 1200);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('checkout-page-container')) {
    window.checkoutInstance = new CheckoutController();
  }
});
