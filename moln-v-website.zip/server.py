#!/usr/bin/env python3
"""
MOLN V — Secure Production-Ready Preview Web Server
Features:
  - Cryptographically secure server-side session management (PBKDF2 salted password hashing).
  - Role-Based Access Control (RBAC): enforces 'admin' vs 'customer' authorization.
  - Intercepts all administrative pages and API endpoints with strict 401 Unauthorized / 403 Forbidden enforcement.
  - Prevents public or customer access to administrative functionality.
  - Zero plaintext secrets stored in frontend HTML/JS files.
"""

import http.server
import socketserver
import os
import sys
import json
import secrets
import hashlib
import hmac
import time
from urllib.parse import urlparse, parse_qs
from http import cookies

PORT = int(os.environ.get('PORT', 8000))
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

# ==============================================================================
# SECURE SERVER CONFIGURATION & AUTHENTICATION STORE
# ==============================================================================

# Admin credentials configured via environment variables (never in frontend code)
ADMIN_USERNAME = os.environ.get('MOLN_ADMIN_USERNAME', 'moln_admin')
ADMIN_RAW_PASSWORD = os.environ.get('MOLN_ADMIN_PASSWORD', 'MolnAtelier@2026!Secure')

def hash_password(password, salt=None):
    if not salt:
        salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000).hex()
    return f"{salt}:{hashed}"

def verify_password(password, stored_hash):
    try:
        salt, hashed = stored_hash.split(':')
        test_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000).hex()
        return hmac.compare_digest(hashed, test_hash)
    except Exception:
        return False

# Server salted credential hash
ADMIN_CREDENTIAL_HASH = hash_password(ADMIN_RAW_PASSWORD)

# In-memory secure server session store:
# token -> {"user": str, "role": "admin"|"customer", "expires_at": float}
SERVER_SESSIONS = {}
SESSION_EXPIRATION_SECONDS = 14400  # 4 hours

# Rate limiting for authentication attempts: ip -> [timestamps]
LOGIN_ATTEMPTS = {}
MAX_ATTEMPTS = 5
LOCKOUT_WINDOW_SECONDS = 900  # 15 minutes

# Server-side persistent storage for orders, inquiries, settings (separated from public static frontend)
SERVER_DATA = {
    "orders": [],
    "inquiries": [],
    "settings": {
        "storeName": "MOLN V",
        "announcementText": "Complimentary express delivery across the GCC on orders over 500 SAR",
        "contactEmail": "concierge@molnv.com",
        "contactPhone": "+20 11 2298 3570",
        "whatsappNumber": "201122983570",
        "freeShippingThresholdSAR": 500
    }
}

# ==============================================================================
# HTML TEMPLATES (RENDERED ONLY FOR AUTHENTICATED ROLES)
# ==============================================================================

def get_admin_login_html(error_message=None):
    """Server-rendered login page served when unauthenticated requests hit /admin.html"""
    error_banner = f"""
    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; border-radius: 6px; padding: 0.85rem 1rem; margin-bottom: 1.5rem; color: #fca5a5; font-size: 0.88rem;">
      {error_message}
    </div>
    """ if error_message else ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MOLN V Atelier — Authenticated Administration</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="icon" type="image/png" href="/assets/images/logo.png">
</head>
<body style="min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #030816; padding: 2rem 1rem;">
  
  <div style="width: 100%; max-width: 440px; background: #071228; border: 1px solid rgba(214, 230, 243, 0.15); border-radius: 12px; padding: 2.5rem 2rem; box-shadow: 0 20px 40px rgba(0,0,0,0.6);">
    
    <div style="text-align: center; margin-bottom: 2rem;">
      <a href="/" class="brand-logo-link" style="justify-content: center; margin-bottom: 1rem;">
        <img src="/assets/images/logo.jpg" alt="MOLN V" style="width: 44px; height: 44px; border-radius: 6px;">
        <div class="brand-logo-text" style="text-align: left;">
          <span class="brand-title" style="font-size: 1.25rem;">MOLN V</span>
          <span class="brand-subtitle">Haute Parfumerie</span>
        </div>
      </a>
      <span class="section-eyebrow" style="color: var(--color-sapphire); letter-spacing: 0.15em;">Restricted Access</span>
      <h1 style="color: #fff; font-size: 1.35rem; margin-top: 0.25rem;">Atelier Admin Portal</h1>
      <p style="color: var(--color-slate-400); font-size: 0.82rem; margin-top: 0.5rem;">
        Requires verified server-side administrator credentials.
      </p>
    </div>

    {error_banner}

    <form id="admin-login-form" method="POST" action="/api/admin/login">
      <div style="margin-bottom: 1.25rem;">
        <label style="display: block; font-size: 0.78rem; text-transform: uppercase; font-weight: 600; color: var(--color-powder-blue); margin-bottom: 0.4rem;">
          Admin Username
        </label>
        <input type="text" name="username" required autocomplete="username" class="form-control" placeholder="Enter username" style="width: 100%; padding: 0.75rem 1rem; background: rgba(0, 9, 38, 0.7); border: 1px solid rgba(214, 230, 243, 0.2); border-radius: 6px; color: #fff;">
      </div>

      <div style="margin-bottom: 1.75rem;">
        <label style="display: block; font-size: 0.78rem; text-transform: uppercase; font-weight: 600; color: var(--color-powder-blue); margin-bottom: 0.4rem;">
          Admin Password
        </label>
        <input type="password" name="password" required autocomplete="current-password" class="form-control" placeholder="••••••••••••" style="width: 100%; padding: 0.75rem 1rem; background: rgba(0, 9, 38, 0.7); border: 1px solid rgba(214, 230, 243, 0.2); border-radius: 6px; color: #fff;">
      </div>

      <button type="submit" class="btn btn-primary btn-block" style="width: 100%; padding: 0.85rem; font-size: 0.95rem; font-weight: 600;">
        Sign In to Atelier Console
      </button>

      <div style="text-align: center; margin-top: 1.5rem; font-size: 0.78rem;">
        <a href="/" style="color: var(--color-slate-400); text-decoration: none;">← Return to Customer Storefront</a>
      </div>
    </form>

  </div>

  <script>
    document.getElementById('admin-login-form').addEventListener('submit', async (e) => {{
      e.preventDefault();
      const form = e.target;
      const data = {{
        username: form.username.value.trim(),
        password: form.password.value
      }};

      try {{
        const res = await fetch('/api/admin/login', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body: JSON.stringify(data)
        }});
        const json = await res.json();
        if (res.ok && json.success) {{
          window.location.href = json.redirect || '/admin.html';
        }} else {{
          alert(json.error || 'Authentication failed. Please check credentials.');
        }}
      }} catch (err) {{
        alert('Server connection error. Please verify server is running.');
      }}
    }});
  </script>
</body>
</html>"""

def get_forbidden_html(user, role):
    """Server-rendered 403 Forbidden page served when a customer account attempts admin access"""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>403 Forbidden — Access Denied | MOLN V</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="icon" type="image/png" href="/assets/images/logo.png">
</head>
<body style="min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #030816; padding: 2rem 1rem;">
  <div style="max-width: 540px; text-align: center; background: #071228; border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 3rem 2rem;">
    <div style="font-size: 3rem; margin-bottom: 1rem; color: #ef4444;">🛡️</div>
    <span class="section-eyebrow" style="color: #ef4444;">Role-Based Access Control (RBAC)</span>
    <h1 style="color: #fff; font-size: 1.5rem; margin-bottom: 1rem;">403 Forbidden: Access Denied</h1>
    <p style="color: var(--color-slate-400); font-size: 0.95rem; line-height: 1.7; margin-bottom: 1.5rem;">
      You are currently authenticated as <strong style="color: #fff;">{user}</strong> with role <strong style="color: #f59e0b;">{role}</strong>.
      Customer accounts do not possess administrative clearance to access the Brand Management Console.
    </p>
    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
      <a href="/account.html" class="btn btn-primary">My Customer Account</a>
      <a href="/" class="btn btn-secondary">Explore Fragrances</a>
    </div>
  </div>
</body>
</html>"""

def get_authenticated_admin_dashboard_html(user):
    """Server-rendered protected dashboard served ONLY to authenticated admins"""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MOLN V — Atelier Management Console [Authenticated Session]</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="stylesheet" href="/assets/css/admin.css">
  <link rel="icon" type="image/png" href="/assets/images/logo.png">
</head>
<body class="admin-body">

  <div class="admin-layout">
    
    <!-- Sidebar Navigation -->
    <aside class="admin-sidebar">
      <div class="admin-brand">
        <img src="/assets/images/logo.jpg" alt="MOLN V" class="admin-brand-logo">
        <div>
          <div class="admin-brand-name">MOLN V</div>
          <div style="font-size: 0.65rem; color: #10B981; letter-spacing: 0.15em;">ADMIN SECURE SESSION</div>
        </div>
      </div>

      <nav class="admin-nav">
        <div class="admin-nav-item active" data-tab="dashboard">
          <svg class="admin-nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
          Dashboard Overview
        </div>

        <div class="admin-nav-item" data-tab="products">
          <svg class="admin-nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
          Fragrance Catalog
        </div>

        <div class="admin-nav-item" data-tab="orders">
          <svg class="admin-nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
          Orders & Fulfillment
        </div>

        <div class="admin-nav-item" data-tab="inquiries">
          <svg class="admin-nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
          Customer Inquiries
        </div>

        <div class="admin-nav-item" data-tab="settings">
          <svg class="admin-nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
          Store & GCC Settings
        </div>
      </nav>

      <div class="admin-sidebar-footer" style="padding: 1.25rem 1rem;">
        <div style="font-size: 0.75rem; color: var(--color-slate-400); margin-bottom: 0.5rem;">
          Operator: <strong style="color: #fff;">{user}</strong>
        </div>
        <button id="btn-admin-logout" class="btn btn-secondary btn-sm btn-block" style="font-size: 0.78rem; border-color: rgba(239, 68, 68, 0.4); color: #fca5a5;">
          Sign Out of Admin ⎋
        </button>
      </div>
    </aside>

    <!-- Main Workspace -->
    <main class="admin-main">
      
      <!-- Mobile Admin Navigation Bar -->
      <nav class="admin-mobile-nav" aria-label="Admin Navigation Tabs">
        <button type="button" class="btn btn-secondary btn-sm admin-nav-item active" data-tab="dashboard">Dashboard</button>
        <button type="button" class="btn btn-secondary btn-sm admin-nav-item" data-tab="products">Catalog</button>
        <button type="button" class="btn btn-secondary btn-sm admin-nav-item" data-tab="orders">Orders</button>
        <button type="button" class="btn btn-secondary btn-sm admin-nav-item" data-tab="inquiries">Inquiries</button>
        <button type="button" class="btn btn-secondary btn-sm admin-nav-item" data-tab="settings">Settings</button>
      </nav>

      <!-- Top Action Bar -->
      <div class="admin-header">
        <div>
          <h1 class="admin-title">MOLN V Atelier Console</h1>
          <div class="admin-subtitle">Authenticated Session • Verified Administrator: <strong>{user}</strong></div>
        </div>

        <div style="display: flex; gap: 0.75rem; align-items: center;">
          <a href="/" class="btn btn-secondary btn-sm" target="_blank">Open Storefront ↗</a>
          <button class="btn btn-primary btn-sm" id="btn-open-add-product">+ Add New Fragrance</button>
        </div>
      </div>

      <!-- TAB 1: DASHBOARD OVERVIEW -->
      <div class="admin-tab-view" id="view-dashboard">
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-label">Total Revenue</div>
            <div class="stat-value" id="stat-revenue">0.00 SAR</div>
            <div class="stat-subtext">Verified Real Customer Orders</div>
          </div>

          <div class="stat-card">
            <div class="stat-label">Total Orders</div>
            <div class="stat-value" id="stat-orders">0</div>
            <div class="stat-subtext">Production Orders</div>
          </div>

          <div class="stat-card">
            <div class="stat-label">Average Order Value</div>
            <div class="stat-value" id="stat-aov">0.00 SAR</div>
            <div class="stat-subtext">Luxury Basket Metric</div>
          </div>

          <div class="stat-card">
            <div class="stat-label">Customer Inquiries</div>
            <div class="stat-value" id="stat-inquiries">0</div>
            <div class="stat-subtext">Concierge Submissions</div>
          </div>
        </div>

        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Recent Customer Orders</h3>
            <button class="btn btn-secondary btn-sm" onclick="window.adminInstance.switchTab('orders')">View All Orders →</button>
          </div>

          <div class="table-responsive">
            <table class="admin-table">
              <thead>
                <tr>
                  <th>Order Reference</th>
                  <th>Date</th>
                  <th>Customer</th>
                  <th>Destination</th>
                  <th>Total Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody id="dashboard-recent-orders">
                <!-- Dynamically populated from server -->
              </tbody>
            </table>
          </div>
        </div>

      </div>

      <!-- TAB 2: PRODUCTS MANAGER -->
      <div class="admin-tab-view" id="view-products" style="display: none;">
        <div class="admin-card">
          <div class="admin-card-header">
            <div>
              <h3 class="admin-card-title">Fragrance Editions Catalog</h3>
              <p style="font-size: 0.78rem; color: var(--admin-text-muted); margin-top: 2px;">
                Manage editions, prices in SAR, inventory counts, and olfactory pyramid accords.
              </p>
            </div>
            <button class="btn btn-primary btn-sm" onclick="document.getElementById('btn-open-add-product').click()">+ Add Fragrance</button>
          </div>

          <div class="table-responsive">
            <table class="admin-table">
              <thead>
                <tr>
                  <th>Fragrance Edition</th>
                  <th>Olfactory Family</th>
                  <th>Price (SAR)</th>
                  <th>Stock Count</th>
                  <th>Badge Label</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="admin-products-table-body">
                <!-- Loaded from store -->
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- TAB 3: ORDERS MANAGER -->
      <div class="admin-tab-view" id="view-orders" style="display: none;">
        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Customer Orders Management</h3>
            <span style="font-size: 0.8rem; color: var(--color-powder-blue);">Server Verified Data</span>
          </div>

          <div class="table-responsive">
            <table class="admin-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Date</th>
                  <th>Client Details</th>
                  <th>Items Ordered</th>
                  <th>Total</th>
                  <th>Fulfillment Status</th>
                </tr>
              </thead>
              <tbody id="admin-orders-table-body">
                <!-- Loaded from store -->
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- TAB 4: CUSTOMER INQUIRIES -->
      <div class="admin-tab-view" id="view-inquiries" style="display: none;">
        <div class="admin-card">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Concierge Inquiries Inbox</h3>
            <span style="font-size: 0.8rem; color: var(--admin-text-muted);">Real Customer Submissions</span>
          </div>

          <div id="admin-inquiries-list">
            <!-- Loaded from store -->
          </div>
        </div>
      </div>

      <!-- TAB 5: STORE & GCC SETTINGS -->
      <div class="admin-tab-view" id="view-settings" style="display: none;">
        <div class="admin-card" style="max-width: 800px;">
          <div class="admin-card-header">
            <h3 class="admin-card-title">Brand & Regional Store Configuration</h3>
            <span style="font-size: 0.8rem; color: var(--color-powder-blue);">Changes apply immediately</span>
          </div>

          <form id="admin-settings-form">
            <div class="form-group">
              <label class="form-label">Brand Name</label>
              <input type="text" id="setting-store-name" class="form-control" value="MOLN V">
            </div>

            <div class="form-group">
              <label class="form-label">Top Announcement Bar Text</label>
              <input type="text" id="setting-announcement" class="form-control" value="Complimentary express delivery across the GCC on orders over 500 SAR">
            </div>

            <div class="form-row-2col">
              <div class="form-group">
                <label class="form-label">Contact / Concierge Email</label>
                <input type="email" id="setting-email" class="form-control" value="concierge@molnv.com">
              </div>
              <div class="form-group">
                <label class="form-label">Contact Phone</label>
                <input type="text" id="setting-phone" class="form-control" value="+20 11 2298 3570">
              </div>
            </div>

            <div class="form-row-2col">
              <div class="form-group">
                <label class="form-label">WhatsApp Concierge Number (Digits only, GCC code)</label>
                <input type="text" id="setting-whatsapp" class="form-control" value="201122983570">
              </div>
              <div class="form-group">
                <label class="form-label">Complimentary Shipping Threshold (SAR)</label>
                <input type="number" id="setting-free-shipping" class="form-control" value="500">
              </div>
            </div>

            <div style="margin-top: 1.5rem; display: flex; gap: 1rem; flex-wrap: wrap;">
              <button type="submit" class="btn btn-primary btn-lg">Save Settings</button>
            </div>
          </form>
        </div>
      </div>

    </main>
  </div>

  <!-- Product Add / Edit Modal -->
  <div class="modal-overlay" id="admin-product-modal">
    <div class="modal-content">
      <button class="modal-close-btn" id="btn-close-product-modal">&times;</button>
      <h2 style="font-size: 1.35rem; color: #fff; margin-bottom: 1.5rem;" id="modal-title">Add Fragrance Edition</h2>

      <form id="admin-product-form">
        <input type="hidden" id="modal-product-id">

        <div class="form-row-2col">
          <div class="form-group">
            <label class="form-label">Fragrance Title *</label>
            <input type="text" id="modal-p-name" class="form-control" required placeholder="e.g. MOLN V — Edition VI">
          </div>
          <div class="form-group">
            <label class="form-label">Subtitle / Signature *</label>
            <input type="text" id="modal-p-subtitle" class="form-control" required placeholder="e.g. Arctic Iris">
          </div>
        </div>

        <div class="form-row-3col">
          <div class="form-group">
            <label class="form-label">Price (SAR) *</label>
            <input type="number" id="modal-p-price" class="form-control" required placeholder="420" step="1">
          </div>
          <div class="form-group">
            <label class="form-label">Initial Stock *</label>
            <input type="number" id="modal-p-stock" class="form-control" required placeholder="50">
          </div>
          <div class="form-group">
            <label class="form-label">Badge Label</label>
            <input type="text" id="modal-p-badge" class="form-control" placeholder="New Release">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Fragrance Family *</label>
          <input type="text" id="modal-p-family" class="form-control" required placeholder="e.g. Woody Oriental, Amber Gourmand, Fresh Aquatic">
        </div>

        <div class="form-group">
          <label class="form-label">Top Notes (Olfactory Pyramid)</label>
          <input type="text" id="modal-p-top" class="form-control" placeholder="e.g. Italian Bergamot, Crisp Juniper, Pink Pepper">
        </div>

        <div class="form-group">
          <label class="form-label">Heart Notes</label>
          <input type="text" id="modal-p-heart" class="form-control" placeholder="e.g. Florentine Iris, Nordic Cedarwood">
        </div>

        <div class="form-group">
          <label class="form-label">Base Notes</label>
          <input type="text" id="modal-p-base" class="form-control" placeholder="e.g. Smoked Incense, Rich Patchouli, Sovereign Musk">
        </div>

        <div class="form-group">
          <label class="form-label">Editorial Description</label>
          <textarea id="modal-p-desc" class="form-control" placeholder="Describe the sensory evolution and architectural character of the scent..."></textarea>
        </div>

        <div style="margin-top: 1.5rem; display: flex; gap: 1rem;">
          <button type="submit" class="btn btn-primary btn-block">Save Fragrance Edition</button>
        </div>
      </form>
    </div>
  </div>

  <script src="/assets/js/store.js"></script>
  <script src="/assets/js/admin.js"></script>
  <script>
    document.getElementById('btn-admin-logout').addEventListener('click', async () => {{
      try {{
        await fetch('/api/admin/logout', {{ method: 'POST' }});
        window.location.href = '/';
      }} catch (e) {{
        window.location.href = '/';
      }}
    }});
  </script>
</body>
</html>"""

# ==============================================================================
# SECURE HTTP REQUEST HANDLER
# ==============================================================================

class SecureAtelierHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def get_client_ip(self):
        return self.client_address[0] if self.client_address else "127.0.0.1"

    def get_session(self):
        cookie_header = self.headers.get('Cookie')
        if not cookie_header:
            return None
        
        c = cookies.SimpleCookie()
        try:
            c.load(cookie_header)
        except Exception:
            return None

        if 'moln_auth_session' not in c:
            return None

        token = c['moln_auth_session'].value
        session = SERVER_SESSIONS.get(token)
        if not session:
            return None

        # Check expiration
        if time.time() > session.get('expires_at', 0):
            del SERVER_SESSIONS[token]
            return None

        return session

    def is_rate_limited(self):
        ip = self.get_client_ip()
        now = time.time()
        attempts = [t for t in LOGIN_ATTEMPTS.get(ip, []) if now - t < LOCKOUT_WINDOW_SECONDS]
        LOGIN_ATTEMPTS[ip] = attempts
        return len(attempts) >= MAX_ATTEMPTS

    def record_failed_login(self):
        ip = self.get_client_ip()
        LOGIN_ATTEMPTS.setdefault(ip, []).append(time.time())

    def clear_failed_logins(self):
        ip = self.get_client_ip()
        if ip in LOGIN_ATTEMPTS:
            del LOGIN_ATTEMPTS[ip]

    def send_json(self, status_code, data, extra_headers=None):
        payload = json.dumps(data).encode('utf-8')
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(payload)

    def send_html(self, status_code, html_content, extra_headers=None):
        payload = html_content.encode('utf-8')
        self.send_response(status_code)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # Normalize subpath for GitHub Pages simulation
        subpath = '/-MOLN-.-V-'
        if path.startswith(subpath):
            path = path[len(subpath):] or '/'

        # Route: Admin API Session Check
        if path == '/api/admin/session':
            session = self.get_session()
            if session:
                self.send_json(200, {
                    "authenticated": True,
                    "user": session.get("user"),
                    "role": session.get("role")
                })
            else:
                self.send_json(200, {"authenticated": False, "role": None})
            return

        # Route: Admin Protected APIs (Orders, Inquiries, Settings)
        if path.startswith('/api/admin/'):
            session = self.get_session()
            if not session:
                self.send_json(401, {"error": "Unauthorized: Admin session required"})
                return
            if session.get("role") != "admin":
                self.send_json(403, {"error": "Forbidden: Customer accounts do not have administrative clearance."})
                return

            if path == '/api/admin/orders':
                self.send_json(200, SERVER_DATA["orders"])
                return
            elif path == '/api/admin/inquiries':
                self.send_json(200, SERVER_DATA["inquiries"])
                return
            elif path == '/api/admin/settings':
                self.send_json(200, SERVER_DATA["settings"])
                return

        # Route: Admin Portal Access Interception (/admin.html or /admin)
        if path in ['/admin.html', '/admin', '/admin/']:
            session = self.get_session()
            if not session:
                # HTTP 401 Unauthorized -> Serve Server-Side Authentication Login Portal
                self.send_html(401, get_admin_login_html())
                return
            
            # Check Role-Based Access Control (RBAC)
            if session.get("role") != "admin":
                # HTTP 403 Forbidden -> Deny access to customer accounts
                self.send_html(403, get_forbidden_html(session.get("user", "Customer"), session.get("role", "customer")))
                return

            # Authorized Admin -> Serve Protected Management Console
            self.send_html(200, get_authenticated_admin_dashboard_html(session.get("user", "Admin")))
            return

        # Standard Storefront Static File Serving
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        content_len = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_len).decode('utf-8') if content_len > 0 else ""

        # Endpoint: Admin Login Authentication
        if path == '/api/admin/login':
            if self.is_rate_limited():
                self.send_json(429, {
                    "success": False,
                    "error": "Too many failed attempts. Temporary lockout for 15 minutes."
                })
                return

            try:
                # Supports JSON and Form Encoded
                if self.headers.get('Content-Type', '').startswith('application/json'):
                    data = json.loads(body)
                else:
                    data = {k: v[0] for k, v in parse_qs(body).items()}
            except Exception:
                self.send_json(400, {"success": False, "error": "Malformed request payload."})
                return

            username = data.get('username', '').strip()
            password = data.get('password', '')

            # Verify credentials on server with constant-time comparison
            if hmac.compare_digest(username, ADMIN_USERNAME) and verify_password(password, ADMIN_CREDENTIAL_HASH):
                self.clear_failed_logins()
                session_token = secrets.token_hex(32)
                SERVER_SESSIONS[session_token] = {
                    "user": username,
                    "role": "admin",
                    "created_at": time.time(),
                    "expires_at": time.time() + SESSION_EXPIRATION_SECONDS
                }

                cookie_val = f"moln_auth_session={session_token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_EXPIRATION_SECONDS}"
                self.send_json(200, {
                    "success": True,
                    "redirect": "/admin.html"
                }, extra_headers={"Set-Cookie": cookie_val})
                return
            else:
                self.record_failed_login()
                self.send_json(401, {
                    "success": False,
                    "error": "Invalid administrative credentials."
                })
                return

        # Endpoint: Admin Logout
        if path == '/api/admin/logout':
            session = self.get_session()
            cookie_header = self.headers.get('Cookie')
            if cookie_header:
                c = cookies.SimpleCookie()
                try:
                    c.load(cookie_header)
                    if 'moln_auth_session' in c:
                        token = c['moln_auth_session'].value
                        if token in SERVER_SESSIONS:
                            del SERVER_SESSIONS[token]
                except Exception:
                    pass

            expired_cookie = "moln_auth_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"
            self.send_json(200, {"success": True}, extra_headers={"Set-Cookie": expired_cookie})
            return

        # Endpoint: Simulated Customer Authentication for RBAC Verification
        if path == '/api/customer/test-login':
            # Allows testing that customer accounts are strictly blocked with 403 Forbidden
            cust_token = secrets.token_hex(32)
            SERVER_SESSIONS[cust_token] = {
                "user": "test_customer@molnv.com",
                "role": "customer",
                "created_at": time.time(),
                "expires_at": time.time() + SESSION_EXPIRATION_SECONDS
            }
            cookie_val = f"moln_auth_session={cust_token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_EXPIRATION_SECONDS}"
            self.send_json(200, {
                "success": True,
                "role": "customer",
                "message": "Authenticated as customer account"
            }, extra_headers={"Set-Cookie": cookie_val})
            return

        # Protected Admin POST Endpoints
        if path.startswith('/api/admin/'):
            session = self.get_session()
            if not session:
                self.send_json(401, {"error": "Unauthorized: Admin session required"})
                return
            if session.get("role") != "admin":
                self.send_json(403, {"error": "Forbidden: Customer accounts do not have administrative clearance."})
                return

            try:
                data = json.loads(body) if body else {}
            except Exception:
                self.send_json(400, {"error": "Malformed JSON payload"})
                return

            if path == '/api/admin/settings':
                SERVER_DATA["settings"].update(data)
                self.send_json(200, {"success": True, "settings": SERVER_DATA["settings"]})
                return
            elif path == '/api/admin/orders/status':
                order_id = data.get('id')
                new_status = data.get('status')
                found = False
                for o in SERVER_DATA["orders"]:
                    if o.get('id') == order_id:
                        o['status'] = new_status
                        found = True
                        break
                self.send_json(200, {"success": True, "found": found})
                return

        # Fallback 404 for unknown POST
        self.send_json(404, {"error": "API route not found"})

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        super().end_headers()

def run():
    os.chdir(DIRECTORY)
    with socketserver.TCPServer(("", PORT), SecureAtelierHandler) as httpd:
        print("================================================================")
        print("  ✦ MOLN V — Secure Haute Parfumerie Preview Server ✦")
        print("================================================================")
        print(f"  Public Storefront:       http://localhost:{PORT}/")
        print(f"  Customer Catalog:        http://localhost:{PORT}/shop.html")
        print(f"  Customer Account:        http://localhost:{PORT}/account.html")
        print(f"  Admin Console (RBAC):    http://localhost:{PORT}/admin.html")
        print("----------------------------------------------------------------")
        print("  Security Architecture:")
        print("   ✓ Unauthenticated requests to /admin.html receive HTTP 401 & Login Form")
        print("   ✓ Customer sessions receive HTTP 403 Forbidden Access Denied")
        print("   ✓ Administrative role requires server-side PBKDF2 verification")
        print("   ✓ Session tokens delivered via HttpOnly; SameSite=Strict cookies")
        print(f"  Default Local Admin User: {ADMIN_USERNAME}")
        print("================================================================")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down secure server.")
            httpd.server_close()

if __name__ == '__main__':
    run()
